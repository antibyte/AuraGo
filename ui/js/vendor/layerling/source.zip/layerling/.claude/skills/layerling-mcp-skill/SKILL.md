---
name: layerling-mcp-skill
description: Control a live local layerling editor through its MCP server. Use when the assistant needs to list currently open layerling editor tabs, target a tab by editorNumber/projectName, read the current scene, list or select objects, create any of the editor's shapes including threads, springs, gears and raised text, update dimensions/position/rotation, align objects, group/ungroup/cut/separate parts, split solids or holes in two with a plane, list exact CAD edge ids, apply chamfer/fillet to specific edges, hollow bodies into walls, repeat objects in rows or circles (hole rows, bolt circles, teeth), cut the view open with the section view to look inside, inspect editor errors, or capture viewport images from view-cube angles.
---

# layerling MCP

## Quick Start

Use this skill only with a local layerling app running in development mode.

1. Start layerling from the repo:

```bash
npm run dev
```

2. Open an editor tab at `http://localhost:3000/?editor=1`.

3. Configure your MCP client to start the stdio server:

```bash
node scripts/layerling-mcp-server.mjs
```

The MCP server talks to the app through `/api/layerling-mcp`. Open editor tabs heartbeat into that route and receive commands from it. Production and static builds return 404 for the MCP route, unless the server of a self-hosted copy (a NAS, the Docker image) switched it on with `LAYERLING_MCP_REMOTE=true` and `LAYERLING_MCP_TOKEN` (at least 16 characters); then the MCP client needs `LAYERLING_URL` and the same `LAYERLING_MCP_TOKEN`, and an editor tab of that copy must be open.

## Client Compatibility

Codex can use this folder as a skill and the MCP server as tools. Install the folder under `~/.codex/skills/layerling-mcp-skill` and configure the MCP server in Codex.

Claude Code reads this same file directly from the repo: it looks for skills under `.claude/skills/<name>/SKILL.md`, so a copy lives at `.claude/skills/layerling-mcp-skill/SKILL.md` (kept identical to this one by a test, not a symlink - a symlink checked out on Windows without Developer Mode turns into a text file containing the path instead of loading). The repo's `.mcp.json` registers the stdio server project-scoped, so Claude Code starts it automatically; nothing needs installing by hand.

Claude Desktop does not read either kind of skill file, but it can use the same `scripts/layerling-mcp-server.mjs` MCP server through Claude's `mcpServers` JSON config. Use the repository README for client setup examples.

## Targeting Editors

Always call `layerling_list_editors` first when the user mentions multiple projects, tabs, or a number like `49536`.

Use `editorNumber` for follow-up commands. It is a 5-digit per-tab number stored in browser `sessionStorage`, so two open layerling tabs have different numbers. The list also includes `projectName`, `projectId`, URL, shape count, selected count, notice, and last error.

If only one editor is open, commands may omit `editorNumber`; the server will target the sole live editor.

## Core Workflow

Read scene/object state before modifying geometry:

```text
layerling_list_editors
layerling_read_scene({ editorNumber })
layerling_list_objects({ editorNumber })
```

For object edits, use exact object `id` values from the scene. Do not invent object names; names are helpful labels only.

Every object carries a `settings` block beside its dimensions, holding what the dimensions do not say: the side count of a round body, the size and pitch of a thread, the turns of a spring, the taper of a box, the lettering of a text. Every value it reports can be set again through `layerling_create_shape` and `layerling_update_object`. A thread on a standard size also reports its name in `settings.threadSize`. A round body whose `settings.sidesFollowSize` is true has no fixed side count of its own - the number shown is what it is drawn with at its current size, and it changes as the object grows. `includeRawShapes` is only needed for the full shape record and can be large.

Useful tools:

- `layerling_select_objects`: select ids in the live editor.
- `layerling_delete_objects`: delete ids in the live editor, or delete the current selection when ids are omitted.
- `layerling_create_shape`: create any shape the editor has a tile for - `box`, `cube`, `cylinder`, `polygon`, `sphere`, `cone`, `pyramid`, `wedge`, `roundRoof`, `halfSphere`, `torus`, `tube`, `loft`, `text`, `thread`, `spring`, `gear` - or a `sketch` extrusion; a `sketch` with `stroke: { width, align, join, cap }` is built as a frame of that width round its outline (align `center`, `inside` or `outside`), as the editor's Stroke does. Size and everything beyond it are optional and fall back to what the editor uses when the same shape is placed by hand. A `thread` is a rod, a screw, a nut or a tapped hole, set through `threadRole`; its width and depth follow `threadDiameter` and are not given separately. For a standard size pass `threadSize` with its name from the editor's size menu - `M6`, `1/4"-20 UNC`, `G1/2` - instead of `threadDiameter` and `threadPitch`; a `settings` block read back with all three still works, a diameter or pitch that does not match the size is refused. `threadClearance` gives nuts and tapped holes room (default 0.2 mm); `threadBoltClearance` makes a rod or screw that much thinner in diameter (default 0), for a printed bolt that has to go into a metal nut. A `spring` winds right-hand like a usual compression spring; `springHand: "left"` winds it the other way. A G size is a parallel Whitworth pipe thread (BSPP, ISO 228-1, as on fittings for water, gas, hydraulics and pneumatics; G1 is 33.249 mm across with 11 threads per inch) and turns a `v` profile into `whitworth`, the 55 degree profile with rounded crest and root; an M, UNC or UNF size turns `whitworth` back into `v`. A cylinder without `sides` picks its own side count from the diameter, the way the editor does. A `teardrop` is the cross-section of a horizontal hole that prints without supports: `width` is the diameter of its round part, `depth` its length along the hole and `height` the full height up to the tip (about 1.207 x width gives the usual 90 degree tip; the editor's tip angle is derived from it). A `counterbore` (round head pocket, `screwHoleHeadDepth`) or `countersink` (cone, `screwHoleAngle`, 90 for a countersunk screw) is a cutter for a screw head: `width` is the head diameter, `screwHoleShaft` the shaft diameter, `height` the whole length, head end on top; set `hole` and let its top end a little above the surface. A `hinge` is a print-in-place hinge lying open flat: `width` is its length along the axis, `depth` both leaves together, `height` the knuckle diameter; `hingeKnuckles` (odd, default 5), `hingePinDiameter`, `hingeLeafThickness` and `hingeClearance` (default 0.4 mm, raise it if a printer fuses the parts) set the rest, and it prints in one piece. A `loft` ("Übergang" in German) joins an outline at the bottom to another at the top with a straight-ruled wall - a hose adapter, a square fan onto a round duct, a stand: `loftBottomOutline` and `loftTopOutline` are `round` (circle or ellipse), `rectangle` (corners rounded by `loftBottomCorner`/`loftTopCorner`) or `polygon` (`loftBottomSides`/`loftTopSides`), `loftBottomWidth`/`loftBottomDepth` and `loftTopWidth`/`loftTopDepth` size the ends, `loftOffsetX`/`loftOffsetZ` move the top sideways (the bottom stays put), and `loftWall` above 0 makes it a tube open at both ends. `loftTwist` turns the section evenly from bottom to top about the vertical (degrees, up to 360 either way), and `loftTiltX`/`loftTiltZ` tilt the top end (degrees, up to 45: positive raises its front +z edge / its right +x side); the sections tilt evenly on the way up and the highest point stays at the height. Its width and depth are what both ends need together and are not given separately; `settings` reports the ends as the body shows them. It is an exact body, so the edge tool and STEP work on it. A `gear` gets involute teeth that mesh (`gearProfile: "involute"`, the default for a new gear; `"simple"` is the plain straight teeth older designs have, set by `toothSize` and `toothWidth`). An involute gear is set like a gear generator: its `width` and `depth` are its outside diameter, module x (`teeth` + 2), so module 1.5 with 20 teeth is 33 - give both, and change them with `teeth` to keep the module. `gearPressureAngle` (default 20) and `gearBacklash` (play of the pair in mm, default 0.2, half taken off each gear) set the rest. Two gears mesh with the same module and pressure angle at a centre distance of module x (teeth1 + teeth2) / 2 between their centres; for helical gears `helixAngle` is then the true helix angle, and a meshing pair takes the same angle with opposite signs. A `slot` (the capsule) can have one end smaller than the other, a belt guard round two pulleys: `slotEndRatio` is the small end's diameter as a share of the large one (0.1 to 1, default 1 for two equal ends). The large end sits at the start of the long side (-x, or -z when standing), its diameter is the short side, the small end touches the far end, and the sides run as tangents to both, so the centre distance is the long side less both radii. It stays an exact body. Every shape except gear, thread, spring, knurl, hinge, pyramid, bentTube, loft, teardrop, counterbore, countersink and ruler can be tapered through `taperTopWidth`, `taperTopDepth`, `taperBottomWidth` and `taperBottomDepth`, and twisted or leaned through `extrudeTwist`, `extrudeTopOffsetX` and `extrudeTopOffsetZ`; naming one value of a face pins the other one as it stands.
- `layerling_import_file`: import a file as the import window does (STL, OBJ, 3MF, STEP, SVG or a ZIP of them), content as `text` or `base64`; a coloured OBJ (vertex colours, or materials with `mtl`) or 3MF (its own colours, or the filaments of a Bambu Studio, OrcaSlicer or PrusaSlicer project) comes in as one body per colour; a 3MF with several objects comes in as one body per object (and per colour within it). Slicer modifiers, negative volumes and support blockers are left out. An SVG comes in as an extruded sketch body (4 mm high, reading from above as in the drawing) whose fill `layerling_update_object` changes with `stroke` and `silhouette`; only one with more than 2500 lines and curves comes in as a fixed mesh.
- `layerling_import_mesh`: import STL-style mesh data into the editor.
- `layerling_update_object`: set exact dimensions, position, color, name, hole state, `rotation`/`rotationX`/`rotationZ`, `locked`/`hidden`, and the same shape settings `layerling_create_shape` takes - the side count of a cylinder, the diameter of a thread, the turns of a spring, the taper of a box, the lettering of a text. A locked object refuses every change until the same call passes `locked: false`. Changing a thread's diameter moves its width and depth with it, and a head that sat at its standard height moves to the standard for the new size. On an extruded sketch body - an imported SVG among them - `stroke` sets the fill: an object `{ width, align, join }` builds the outline as a frame (`align: "outside"` is Tinkercad's outer line, `"inside"` its inner line, `"center"` on the line; values left out keep the current ones), `null` makes it an area again; `silhouette: true` leaves out every outline inside another (holes and islands in them), `false` brings them back. Outside stroke plus silhouette is a cookie cutter. The body is built again from its sketch where it stands; edge treatments go. The summary shows `sketchStroke` and `silhouette`.
  `rotationPivot: { x, z, elevation }` gives the object a pivot of its own (null removes it): it moves, turns and scales with the object, the rotate handle and the R key turn the object about it, and every object summary reports it. `multicolor` (groups only) shows each part in its own colour instead of the group colour.
- `layerling_align_objects`: align two or more ids using the same logic as the editor Alignment button.
- `layerling_scale_objects`: scale objects by a percentage, the same in every direction, like the editor's Scale by percent tool. `percent` 120 makes them a fifth larger. `mode` `together` (default) scales them around their common centre so the layout grows with them, `each` scales every object in place so the gaps stay. The bottom stays where it is; locked objects are skipped.
- `layerling_place_on_face`: set objects down on a face of another object, as the editor's C key (Tinkercad's Cruise) does: give `targetId` and `targetFace` (a side of the target's own box, default `top`, snapped to the nearest real face; the point is the middle of the target brought straight onto that face) or `point` and `normal` yourself. The underside of the first object turns onto the face, sloped ones included, lined up with it as a shape dropped there would be, and its middle lands on the point; several objects move together. One undo step.
- `layerling_lay_flat`: turn objects so a face rests on the workplane, like the editor's Lay flat tool. Pass `face` (`bottom`/`top`/`left`/`right`/`front`/`back`, a side of the object's own box in its current turn) or `normal` `[x, y, z]` in world coordinates; both snap to the nearest real face. Several ids turn together and keep their spacing.
- `layerling_mate_faces`: move one object (`id`) so its `face` meets the `targetFace` of another (`targetId`), like the editor's Align faces tool. Faces are sides of each object's own box (`bottom`/`top`/`left`/`right`/`front`/`back`) and snap to the nearest real face. It turns the shortest way until the faces are parallel, then slides only along the target face's normal, so the object keeps its place sideways. `mode` is `against` (default, face to face) or `flush` (one plane, side by side); `gap` leaves that many millimetres out of the target face.
- `layerling_group_objects`: group selected ids using the normal layerling group/boolean path.
- `layerling_open_group` / `layerling_close_group`: open a group (the editor's Edit group) so its parts lie loose and can be changed one by one, then close it - rebuilt as the same group, with its own id, name, colour and solid/hole state, or `cancel: true` for the untouched group. A part replaced while the group is open (grouped, cut, separated, ungrouped) stays in it; new shapes, pastes and duplicates do not. While a group is open, a group among its parts can be opened as well, one level deeper each time; close always acts on the innermost level. `layerling_read_scene` shows the innermost one as `openGroup` and every level, outermost first, as `openGroups`.
- `layerling_boolean_cut`: pass `solidIds` and `holeIds`; the result replaces the operands.
- `layerling_intersect_objects`: keep only what the `ids` have in common - two or more solids (a group counts as it looks), or solids against holes. The result replaces the operands; no overlap reports `empty`.
- `layerling_ungroup_objects`: restore grouped children while preserving edited child geometry.
- `layerling_separate_parts`: separate the disconnected parts of one object.
- `layerling_split_objects`: cut solids or holes in two with a plane, like the editor's Split tool. `axis` as in a slicer (`x`, `y` front-back, `z` up, the default), `position` in the numbers `layerling_read_scene` reports (position.x, position.z or elevation; the middle when omitted), `rotationX`/`rotationY`/`rotationZ` in degrees for an angled cut, about either or both of the two axes it does not cut across. Each object the plane crosses becomes two mesh bodies (two holes for a hole; a hollow keeps its cavity), one undo step.
- `layerling_hollow_object`: hollow a solid into walls of equal thickness, open on top, bottom, both, or closed.
- `layerling_array_objects`: repeat objects n times in a row or around a circle (hole rows, bolt circles, teeth) as one undo step.
- `layerling_show_overhangs`: overhangs that would need supports, like "Show overhangs" in the visibility menu. `enabled` switches the red-and-white hatching in the view, `angle` (30-70, default 45, degrees from vertical) is kept in the design's settings. Returns `overhangAreaMm2` and `lowestOverhangHeight` for each visible solid (or `ids`); 0 means it prints without supports at that angle. Faces on the plate do not count, a face resting on another body does. Call it again after `layerling_lay_flat` or a rotation to compare print orientations.
- `layerling_bundle_objects`: hold objects together like Tinkercad's Ctrl+B without merging them - every part keeps its colour and its solid/hole state, holes cut nothing, and an STL/3MF/OBJ export writes each part as its own body (a two-colour logo on a plate stays two coloured parts). Ungroup or open it like a group; the edge tools and hollowing refuse it. Use `layerling_group_objects` when holes should cut.
- `layerling_estimate_print`: volume, weight and 1.75 mm filament length for `ids`, the selection or the whole design, worked out as solid like the export window's Material box (`material`: pla, petg, abs, asa, tpu or pa). It counts what an STL would hold: visible solids, holes in groups taken off, overlaps once. The slicer shows less with infill.
- `layerling_add_reference_points`: mark reference points - bare marks in space that shapes snap to, saved with the design but never printed or exported. `at` is center, corners or midpoints of the objects (`ids`, or the selection) on their top face; or pass exact `points` (`x`, `z`, `elevation`). Points already marked are not added twice. `layerling_list_reference_points` lists them with ids, `layerling_remove_reference_points` deletes some or all.
- `layerling_inspect_errors`: read the editor notice, edge modifier error and last MCP error, plus `recentNotices` and `recentErrors` of the session - what the editor's bug report carries.

## Edge Features

Chamfer and fillet are separate edge-treatment operations in layerling. Do not fake a chamfer/fillet with cylinders or extra decorative geometry. Cylinders are only appropriate when the requested shape itself has a circular/rounded 2D footprint, such as rounded tray corners or a cylindrical peg.

For chamfer/fillet, never guess edge ids.

1. Call `layerling_list_edges({ editorNumber, id, sharpAngle })`.
2. Use returned `selectableEdgeIds` or inspect returned edge geometry.
3. Call `layerling_apply_edge_treatment({ editorNumber, id, kind, edgeIds, amount, chamferAngle })`.

`edgeIds` can be an array of numeric ids, `"all"`, or `"top"` for only the edges along the very top of the body, such as the rim of a cookie cutter made from a stroked sketch (`layerling_create_shape` with `kind: "sketch"` and `stroke`). `kind` is `chamfer` or `fillet`. The app commits the result through normal history, so undo/redo works.

## Hollowing

For a box, cup, case or any body with walls, build the outside shape and hollow it with `layerling_hollow_object({ editorNumber, id, thickness, openings })`. Do not fake walls by subtracting a smaller copy of the shape - that gives uneven walls on anything but a box. The walls grow inward, so the outside keeps its size. `openings` is a list of the sides to leave open - any of `top`, `bottom`, `front` (+z), `back` (-z), `left` (-x) and `right` (+x), e.g. `["front"]` for a drawer slot, `[]` for a sealed cavity - or one of the older names `top` (default), `bottom`, `top-bottom` or `none`; every side needs a flat face at the very edge of the body, measured against the world's axes. `edges` is `round` (default; where the body steps or has an opening, the inner walls meet in a rounding as big as the wall) or `sharp` (they meet in a sharp edge). Too thick a wall is refused with an error - use a thinner one. Resizing a hollowed body later (`layerling_update_object` or the handles) hollows it again at the new size a moment afterwards, so the walls keep their thickness; a cylinder stretched unevenly comes back as an ellipse. Wait a second before measuring the walls.

## Patterns

For a row of holes, a hole grid, a bolt circle or the teeth of a ring, build one piece and repeat it with `layerling_array_objects` instead of creating each copy by hand. Coordinates follow a slicer: X right, Y back, Z up.

- Row: `layerling_array_objects({ editorNumber, ids, mode: "row", count: 5, spacing: 12, direction: "x" })`. `count` includes the original; a negative `spacing` runs the other way. A grid is a row of a row: repeat the returned copies plus the original along the second axis. A row can also step along several axes at once: `spacingX`, `spacingY`, `spacingZ` (a diagonal row, a staircase).
- Circle: `layerling_array_objects({ editorNumber, ids, mode: "circle", count: 6, centerX: 0, centerY: 0 })`. Place the first piece at the radius you want, measured from the centre. `angle` defaults to 360 (evenly spread); a smaller angle spans an arc end to end. `rotateCopies: false` keeps every copy's orientation. `rise` (height per copy) turns the circle into a screw and `radiusChange` (distance from the centre per copy, negative tightens) into a spiral; both together give a conical spiral.

Group the pattern with the body afterwards when the pieces are holes.

## Images

## History view

To compare with an earlier state of the project, call `layerling_set_history_view({ editorNumber, index })` (0 is the oldest state, the last one the current design), then `layerling_capture_image` for a picture of that state. It returns how many states there are, when the one shown was recorded and its bodies. `open: false` closes the view; with no settings it reports where it stands. The real design stays untouched, and while the view is open every tool that changes the design answers with an error - close it first. `layerling_read_scene` keeps describing the live design.

## Section view

To look inside a part - wall thickness after hollowing, a thread in its nut, a cavity, parts that fit into each other - cut the view open with `layerling_set_section_view({ editorNumber, enabled: true, axis, offset })`, then capture an image. Only the view is cut; the design and its exports stay whole. `axis` uses the editor's coordinates like an object's position: `x` cuts across left-right (`offset` is an x position), `z` across front-back (a z position), `y` horizontally (`offset` is a height above the plate, like `elevation`). Switching on, a new axis or `center: true` put the plane in the middle of the design unless `offset` is given; the result returns the plane's useful range (`min`, `max`, `center`). The far side (greater x, z or height) stays visible; `flipped: true` shows the other one. `showPlane: false` hides the blue plane for a clean picture. The editor's section panel names the axes like its position fields instead - X, Y for the depth (`z` here) and Z for the height (`y` here) - so a user's "Y cut" is `axis: "z"` here. Call it with no settings to read the current state, and switch it off with `enabled: false` when done. To get the cut itself as a drawing - for a laser, a plotter, a template or a gasket - call `layerling_export_section_svg({ editorNumber, axis, offset })`: it returns `svg` at 1:1 in millimetres, built from the same bodies as the export (visible solids, holes taken off, one colour joined into one outline), seen from the right for x, from above for y and from the front for z. It leaves the section view as it is; `openLoops` should be 0. To measure on the cut - wall thickness, a gap, a fit - call `layerling_measure_section({ editorNumber, axis, offset, from: { x, z, elevation }, to: { x, z, elevation } })` with `from` near one wall and `to` anywhere near the opposite one: both snap to the cut's outline (`snapRadius`, default 1 mm), `to` square to its wall as seen from `from`, and it returns `distance` with `deltaX`, `deltaZ`, `deltaElevation` and how each point snapped (`perpendicular`, `corner`, `outline` or `free` - free means it missed the outline).

To look at the underside - overhangs, a base, a cavity open at the bottom - hide the plate first with `layerling_show_workplane({ editorNumber, visible: false })`, then capture the bottom view; only the view changes and shapes still land on the workplane. Show it again with `visible: true` when done.

To keep bodies for later designs, `layerling_save_custom_shape({ editorNumber, ids, name, location })` stores them as a custom shape (centred, standing on the plate): on the server's "Custom shapes" folder when the shared store is on (the default there; a name already taken is refused), else in the browser. `layerling_list_custom_shapes` lists both (server ids start with `server:`), `layerling_insert_custom_shape({ editorNumber, id or name, x, z })` puts one into the open design with the middle of its footprint at x/z and returns the new objects, and `layerling_delete_custom_shape` removes one.

To put a logo, an SVG or lettering onto a cup or tube, create it flat on the plate as seen from above, then `layerling_wrap_around_cylinder({ editorNumber, id, diameter })` with the cylinder's outside diameter, and centre it on the cylinder with `layerling_align_objects` on x and z (anchorId = the cylinder): the wrapped body's middle is the axis. For an engraving pass `inward: true`, make it a hole and group it with the cylinder. It refuses a body longer than the circumference and names the smallest diameter that fits.

When an imported mesh is too dense - a cut fails with "too complex to cut", or the editor is slow with it - reduce it with `layerling_simplify_mesh({ editorNumber, id, keepPercent: 50 })` (or `targetTriangles`). `importedTriangles` in `layerling_list_objects` is the current count; the call returns `trianglesBefore` and `trianglesAfter`. Fine detail goes first, so capture an image afterwards and undo if too much is lost. A simplified group becomes one plain mesh and can no longer be ungrouped.

## Workplane

To build on a side of a body - a hole in a wall, text on a front - put the workplane there with `layerling_set_workplane({ editorNumber, id, face: "front" })` (top, bottom, left, right, front or back of the object's own box, snapped to the real face). New shapes from `layerling_create_shape` then land on that face, and `layerling_read_scene` reports `workplane.onBase: false`; the user can do the same with W and a click. `layerling_set_workplane({ editorNumber, reset: true })` puts it back on the base plate. `visible: false` hides a face workplane for a clear look or picture while it keeps applying; `visible: true` shows it again.

Use `layerling_capture_image` for viewport PNGs. `face` can be `current`, `home`, `top`, `bottom`, `front`, `back`, `right`, or `left`, or an edge or corner of the view cube as neighbouring faces joined with `-`: `front-right` looks between two sides, `front-right-top` diagonally from a corner (often the clearest single picture of a part). These use the same camera/view-cube orientation logic as the editor UI. By default the image is the screen as the user sees it, handles and selection frame included. `clean: true` gives the picture the editor's PNG export saves - only the bodies, at twice the resolution - and `plate: false` or `transparent: true` leave out the build plate or the background, for a picture to post or to show the user.

## Visual Verification

After creating or heavily modifying an object, use vision when available. Capture at least one useful viewport image with `layerling_capture_image`; for 3D geometry, prefer `home` plus any needed orthographic-style faces such as `top`, `front`, or `right`. Inspect the rendered result against the user's requirements before saying the task is done.

Do not rely only on numeric scene data when the user asked for a physical object. Use numeric checks for dimensions and visual checks for whether the model reads correctly.

## Safety

This bridge is local-development only. If a command fails, call `layerling_inspect_errors` before retrying. For geometry operations that can be expensive, set a larger `timeoutMs` on the tool call.
