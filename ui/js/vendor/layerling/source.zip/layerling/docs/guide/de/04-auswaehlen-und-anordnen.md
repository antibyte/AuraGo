---
title: Auswählen und Anordnen
summary: Formen auswählen, in der Objektliste finden, ausrichten, spiegeln, drehen, auf eine Fläche legen und in Mustern vervielfachen.
---

## Auswählen

Ein Klick auf eine Form wählt sie aus. Mit [[Umschalt]] nimmst du weitere dazu oder wieder weg. Ein Klick ins Leere hebt die Auswahl auf, ebenso [[Esc]]. Ziehst du auf der leeren Arbeitsebene einen Rahmen auf, wählst du alles aus, was er berührt; mit gehaltenem [[Umschalt]] nimmt der Rahmen dazu, was nicht ausgewählt war, und weg, was es war. Und [[Strg]]+[[A]] wählt alle sichtbaren Körper.

Was du im Weg hast, blendest du aus ({{ui:editor.tool.hideSelected}}, [[Strg]]+[[H]]). Ausgeblendete Formen bleiben im Entwurf, sie sind nur nicht zu sehen und kommen nicht mit in den Export; das Exportfenster sagt vorher, wie viele es sind. Mit [[Strg]]+[[Umschalt]]+[[H]] holst du alle zurück. Was liegen bleiben soll, sperrst du mit dem Schloss oben in den Einstellungen oder mit [[Strg]]+[[L]]. Gesperrte Formen lassen sich weder verschieben noch versehentlich löschen.

## Die Objektliste

Bei vielen Teilen verliert man in der Ansicht leicht den Überblick. Die Objektliste ({{ui:editor.tool.showOutliner}} oder [[Strg]]+[[Umschalt]]+[[O]]) zeigt alle Formen als Liste.

![Die Objektliste: die Gruppe „Gruppe“ mit zwei Teilen und daneben eine Kugel. Ein Ordnersymbol öffnet die Gruppe.](shot:object-list)

- Ein Klick auf einen Eintrag wählt die Form aus, auch die Teile innerhalb einer Gruppe. Mit [[Umschalt]] nimmst du weitere Einträge dazu oder wieder weg, genau wie in der Ansicht. Die Pfeile klappen Gruppen auf und zu.
- Das Etikett zeigt, ob ein Teil {{ui:outliner.solid}} oder {{ui:outliner.hole}} ist.
- Schloss und Auge sperren und verstecken einzelne Teile.
- Über {{ui:outliner.rename}} gibst du einem Teil einen eigenen Namen; der Stift neben dem Namen oben in den Einstellungen macht dasselbe für die ausgewählte Form. Vernünftige Namen helfen bei größeren Entwürfen enorm.
- Das Suchfeld findet Formen nach Namen und nach Art, also auch „Zylinder“ oder „Aussparung“. Es sucht auch in Gruppen, egal wie tief verschachtelt: Eine Gruppe mit einem Treffer bleibt in der Liste und klappt auf, sodass die passenden Teile und die Gruppen auf dem Weg dorthin zu sehen sind. Passt der Name der Gruppe selbst, zeigt sie aufgeklappt alle ihre Teile.
- Der Pfeil ganz links in der Titelleiste klappt die Liste bis auf ihre Titelleiste ein und wieder auf.

Die Liste ist rechts neben dem Ansichtswürfel angedockt. An ihrer Titelleiste ziehst du sie an jede Stelle der Arbeitsfläche; dabei gleitet sie unter dem Ansichtswürfel und der Kameraleiste hindurch. Legst du sie neben dem Ansichtswürfel wieder ab oder doppelklickst auf die Titelleiste, dockt sie wieder an. Wo sie stand und ob sie eingeklappt war, merkt sich der Browser.

## Position eintippen

Die Karte {{ui:inspector.position}} im Eigenschaftenfenster zeigt, wo der ausgewählte Körper steht, und du kannst es eintippen: {{ui:prop.positionX}} und {{ui:prop.positionY}} sind die Mitte seines Rahmens auf der Platte, mit denselben Vorzeichen wie die Abstände auf der Arbeitsfläche, {{ui:prop.positionZ}} ist die Höhe seiner Unterkante. X zählt nach rechts, Y nach hinten und Z nach oben, nach der Rechte-Hand-Regel wie in Tinkercad und CAD-Programmen; die Achsenpfeile an der Platte zeigen die Richtungen. Die Werte gelten in der eingestellten Einheit, und die Regler reichen so weit wie das Ziehen.

## Teile neben der Platte parken

Du kannst eine Form über den Rand der Platte hinausziehen und dort liegen lassen, etwa eine Plattenbreite weit auf jeder Seite, um sie für später aufzuheben. Mit den Pfeiltasten geht es beliebig weit. Ein geparktes Teil gehört weiter zum Entwurf und landet mit im Export. Soll es draußen bleiben, blende es aus oder exportiere nur die Auswahl. Hast du einen Drucker gewählt, warnt layerling beim Export, wenn etwas außerhalb seiner Platte liegt.

## Fangen beim Verschieben

Ziehst du eine Form über die Arbeitsebene, rastet sie an anderen Formen ein: Ihre linke, rechte, vordere oder hintere Kante oder ihre Mitte legt sich genau auf eine Kante oder Mitte einer anderen Form. Eine rosa Hilfslinie zeigt, woran sie gerade hängt. So stellst du zwei Teile bündig nebeneinander oder mittig hintereinander, ohne Zahlen einzutippen. Das gilt auch, wenn das Raster ausgeschaltet ist.

Hältst du beim Ziehen [[Umschalt]] gedrückt, bleibt die Bewegung auf einer Achse: Die Form folgt der Richtung, X oder Y, in die du weiter gezogen hast, und lässt die andere unberührt. Drück [[Umschalt]] am besten erst, wenn du schon ziehst; auf einer Form, die noch nicht ausgewählt ist, nimmt ein Klick mit [[Umschalt]] sie nur zur Auswahl dazu.

Ist [[Alt]] schon gedrückt, wenn das Ziehen beginnt, ziehst du eine Kopie, wie in Tinkercad: Die Form bleibt, wo sie ist, und die Kopie landet dort, wo du loslässt. Drückst du [[Alt]] erst unterwegs, setzt das Fangen aus und die Form folgt nur dem Raster. Auch beim Ziehen einer Kopie fängt sie erst, wenn du [[Alt]] unterwegs loslässt. Ganz abschalten lässt sich das Fangen im Rastermenü unten rechts ({{ui:inspector.objectSnap}}) oder in den Einstellungen. Bisher fängt nur das Verschieben auf der normalen Arbeitsebene, nicht das Anheben und nicht die Größenänderung.

## Ausrichten

Zwei oder mehr ausgewählte Formen richtest du mit {{ui:editor.tool.align}} aneinander aus: Am Rand der Auswahl erscheinen Punkte für links, mittig und rechts, vorn, mittig und hinten sowie oben, mittig und unten. Ein Klick auf einen Punkt schiebt alle Formen dorthin. Klickst du zuerst eine der ausgewählten Formen an, bleibt sie an ihrem Platz und die anderen richten sich nach ihr.

![Das Ausrichten zeigt an den Rändern der Auswahl die möglichen Ziele als Punkte.](shot:align)

Die Taste dafür ist [[L]]. [[Esc]] bricht ab.

## Spiegeln

{{ui:editor.tool.mirror}} ([[M]]) kippt die Auswahl an einer Ebene: {{ui:mirror.leftRight}}, {{ui:mirror.frontBack}} oder {{ui:mirror.topBottom}}. Klicke dazu auf den passenden Achsenpfeil. Das ist praktisch für symmetrische Teile: Baue eine Hälfte, kopiere sie und spiegele die Kopie.

## Drehen und den Drehpunkt setzen

Gedreht wird mit den gebogenen Pfeilen an der Form, mit den Zahlen in den Einstellungen oder mit [[R]] in 45°-Schritten. Normalerweise dreht sich die Auswahl um ihre Mitte. Manchmal soll sie das nicht, etwa wenn ein gekipptes Rohr an seinem Ende weitergedreht werden soll. Dafür gibt es {{ui:editor.tool.rotationPivot}}: Klicke danach auf eine Fläche. Eine ebene Fläche gibt ihren Mittelpunkt vor, zum Beispiel die Achse eines Rohrendes. Die Auswahl dreht sich jetzt um diesen Punkt. Ein zweiter Klick auf das Werkzeug hebt ihn wieder auf.

Die Winkel bleiben am Körper. In seinen Einstellungen zeigt {{ui:inspector.rotation}} sie als {{ui:prop.rotateX}}, {{ui:prop.rotateY}} und {{ui:prop.rotateZ}}, benannt wie die Position: Y läuft quer über die Platte, Z nach oben. Tippst du dort einen Winkel ein, dreht sich der Körper darauf – um seine Mitte oder um seinen eigenen Drehpunkt, falls er einen hat. Solange ein gedrehter Körper ausgewählt ist, stehen seine Winkel auch unter ihm auf der Arbeitsfläche; {{ui:workspace.showRotationAngles}} in den Einstellungen schaltet das ab.

![Ein um zwei Achsen gedrehter Körper: Seine Winkel stehen unter ihm, und die Karte „Drehung“ in seinen Einstellungen nimmt sie als Zahlen.](shot:rotation-card)

Ist **ein Körper** gewählt, gehört der Drehpunkt zu diesem Körper: Wähle andere Teile und komm zurück, und er ist noch da. Er wandert, dreht sich und skaliert mit dem Körper, wird im Projekt gespeichert und kommt mit „Rückgängig“ zurück. Unter {{ui:inspector.position}} hat der Drehpunkt eigene Werte für X, Y und Z, die du eintippen oder verschieben kannst, und {{ui:inspector.pivotRemove}} nimmt ihn weg. Die rote Markierung des Drehpunkts kannst du auch mit der Maus ziehen: Sie gleitet über die Oberfläche der Körper und rastet an Ecken, Kantenmitten und Kanten ein, so dass ein Scharnierstift genau auf eine Ecke kommt. Sind mehrere Körper gewählt, gilt der Drehpunkt nur für diese Auswahl, und eine neue Auswahl hebt ihn auf.

## Auf eine Fläche legen

Ein Teil soll für den Druck auf seiner besten Seite liegen? Wähle es aus, klicke auf {{ui:editor.tool.layFlat}} und dann auf die Fläche, die nach unten soll. Wenn du mit dem Zeiger über das Teil fährst, leuchtet die Fläche darunter auf, du siehst also vorher, welche du gleich nimmst; drehe die Ansicht, um die anderen Seiten zu prüfen. Das Teil dreht sich so, dass diese Fläche auf der Arbeitsebene liegt.

Zwei Teile sollen Fläche an Fläche liegen oder bündig abschließen? Wähle das Teil aus, das sich bewegen soll, klicke auf {{ui:editor.tool.mateFaces}}, dann auf seine Fläche und danach auf die Fläche des anderen Teils. Im Panel legt {{ui:mate.mode.against}} die Flächen aneinander (Rücken an Rücken, berührend), {{ui:mate.mode.flush}} legt sie nebeneinander in eine Ebene; {{ui:mate.gap}} lässt Platz dazwischen, etwa als Spiel. {{ui:mate.apply}} bewegt das Teil: Es dreht sich auf kürzestem Weg, bis die Flächen parallel sind – gar nicht, wenn sie es schon sind –, und rückt dann nur auf die andere Fläche zu, behält seine seitliche Lage also. Das andere Teil bleibt, wo es ist, und ein Rückgängig nimmt alles zurück.

![Das Fenster „Flächen ausrichten“: Das Teil, das sich bewegt, ist gewählt, als Nächstes kommt eine Fläche des anderen Teils, dann „Gegeneinander“ oder „Bündig“ und ein Abstand, wenn du willst.](shot:mate-faces)

Ähnlich einfach sind {{ui:editor.tool.dropToWorkplane}} ([[D]]), das die Auswahl auf die Arbeitsebene absetzt, und {{ui:editor.tool.centerOnWorkplane}}.

Mit [[C]] nimmst du die Auswahl auf, wie mit Cruise in Tinkercad: Sie hängt am Mauszeiger und legt sich auf die Fläche eines anderen Körpers, über der du gerade bist, auch auf eine schräge. Ein Klick setzt sie dort ab, [[Esc]] lässt sie, wo sie war. Ihre Unterseite liegt dann auf der Fläche, und sie richtet sich nach deren Kanten aus wie eine neue Form; eine eigene Drehung um ihre Hochachse behält sie. Mehrere Teile wandern zusammen und behalten ihren Abstand. Über der leeren Platte stellt [[C]] ein gekipptes Teil wieder aufrecht auf die Arbeitsebene.

## Muster: Reihe und Kreis

Für Lochraster, Lochkreise und Zahnkränze gibt es das {{ui:editor.tool.array}}. Wähle die Formen aus, die vervielfältigt werden sollen, und klicke im Menüband darauf.

![Das Muster im Modus „Kreis“: Die Kopien erscheinen zuerst als Vorschau.](shot:pattern-tool)

- **{{ui:array.mode.row}}:** Die Auswahl wird mit gleichem Abstand wiederholt. Die Reihe läuft in allen drei Achsen zugleich, mit {{ui:array.spacingX}}, {{ui:array.spacingY}} und {{ui:array.spacingZ}}: Einer allein gibt eine gerade Reihe, zwei oder drei eine schräge Reihe oder eine Treppe. Ein negativer Abstand legt die Reihe in die andere Richtung.
- **{{ui:array.mode.circle}}:** Die Auswahl wird um einen Mittelpunkt verteilt. Wie viele Kopien es gibt, stellst du bei {{ui:array.count}} ein, der {{ui:array.angle}} ist für einen vollen Kreis 360°. Stelle ein, ob sich die Kopien mitdrehen sollen. {{ui:array.rise}} hebt jede Kopie ein Stück höher als die vorige (eine Schraube oder aufsteigende Spirale), und {{ui:array.radiusChange}} rückt sie weiter vom Mittelpunkt weg oder näher heran (eine flache Spirale); zusammen ergeben sie eine kegelige Spirale.

Tipp: Setze vorher mit {{ui:editor.tool.rotationPivot}} den Drehpunkt auf eine Fläche, dann liegt der Mittelpunkt des Kreises genau dort.

![Das Muster im Modus „Kreis" mit Anstieg und Radiusänderung pro Kopie: Die Kopien steigen und weiten sich wie eine Spirale.](shot:pattern-spiral)

Die Kopien erscheinen zuerst als Vorschau. Erst {{ui:array.apply}} legt sie an. Sind die Kopien Aussparungen, gruppierst du sie danach mit dem Körper, in den sie schneiden sollen.

## Mehrere Teile auf einmal ändern

Sind mehrere Teile ausgewählt, zeigt das Eigenschaften-Feld rechts, wie viele es sind, und bietet an, was für alle zugleich gilt: {{ui:inspector.solid}} oder {{ui:inspector.hole}}, eine Farbe für alle (ein Klick auf {{ui:inspector.solid}} öffnet die Farben) und das Schloss zum Sperren. Ist die Auswahl gemischt, macht ein Klick alle zu Körpern oder alle zu Aussparungen. Gesperrte Teile bleiben, wie sie sind. Maße änderst du an einem einzelnen Teil, mit den Griffen oder mit {{ui:scalePercent.title}}. Körper und Aussparung gehen auch per Rechtsklick oder mit [[S]] und [[H]].

## Um Prozent skalieren

Sollen ein oder mehrere Teile um denselben Anteil größer oder kleiner werden, etwa alle Teile einer Druckdatei um 20 %, nimmst du {{ui:scalePercent.title}}. Wähle die Teile aus, klicke mit der rechten Maustaste darauf und wähle {{ui:scalePercent.title}}, oder suche es mit [[Strg]]+[[K]].

Bei {{ui:scalePercent.percent}} gibst du die neue Größe in Prozent der jetzigen ein: 120 % ist ein Fünftel größer, 50 % halb so groß. Breite, Tiefe und Höhe ändern sich dabei gleich, die Proportionen bleiben also erhalten. Die Unterseite bleibt, wo sie ist, so dass nichts in die Platte rutscht.

Bei mehreren Teilen wählst du, wie sie wachsen:

- **{{ui:scalePercent.mode.together}}:** Die Teile wachsen um ihre gemeinsame Mitte, die Abstände wachsen mit. Das Ganze wird größer, als wäre es ein Teil.
- **{{ui:scalePercent.mode.each}}:** Jedes Teil wächst an seinem Platz, die Abstände dazwischen bleiben gleich.

Erst {{ui:scalePercent.apply}} ändert den Entwurf, und ein Schritt zurück macht es wieder rückgängig. Gesperrte Teile bleiben, wie sie sind.

## Rückgängig machen

{{ui:editor.tool.undo}} ([[Strg]]+[[Z]]) und {{ui:editor.tool.redo}} ([[Strg]]+[[Umschalt]]+[[Z]] oder [[Strg]]+[[Y]]) gehen Schritt für Schritt durch deinen Verlauf. Wie viele Schritte mit dem gespeicherten Entwurf mitreisen, stellst du in den Einstellungen unter {{ui:workspace.history}} ein.

## Zurückschauen: die Verlaufsansicht

{{ui:editor.tool.history}}, neben Rückgängig und Wiederherstellen, öffnet einen Blick in deinen Verlauf, ohne etwas zu ändern. Die Arbeitsfläche zeigt den Entwurf, wie er war, und ein Schieber unten geht durch alle Rückgängig-Schritte: ganz rechts der aktuelle Stand, jeder Schritt nach links ein Rückgängig früher, und Stände, die du rückgängig gemacht hast, liegen rechts vom aktuellen. Die Pfeiltasten gehen durch die Stände, [[Esc]] kehrt zum aktuellen Stand zurück. Du kannst die Ansicht derweil drehen und zoomen, aber nichts auswählen oder verschieben; der Entwurf selbst bleibt genau, wie er ist. Verdeckt die Leiste etwas, ziehst du sie an ihrer Titelleiste weg; ein Doppelklick darauf holt sie zurück.

Zwei Dinge kannst du aus einem früheren Stand mitnehmen. {{ui:historyView.createProject}} legt diesen Stand als neuen Entwurf in der Übersicht an, benannt nach diesem hier mit der Zeit des Standes in Klammern - bei einem Entwurf, der gespeichert wurde, bevor layerling Zeiten festhielt, steht stattdessen „Kopie“ - und mit dem Verlauf bis dorthin, sodass Rückgängig dort weitergeht. {{ui:historyView.export}} öffnet den gewohnten Export mit diesem Stand als Entwurf, sodass du ihn als STL, 3MF, STEP, Bild oder LYL-Datei mit dem Verlauf bis zu diesem Stand sichern kannst.
