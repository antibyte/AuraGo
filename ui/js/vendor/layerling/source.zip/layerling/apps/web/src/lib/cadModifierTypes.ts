import type { CadLidRequest } from "@/lib/cadLid";
import type { ThreadOutlineTier } from "@/lib/threadOutline";
import type { ThreadHead } from "@/types/layerling";
import type { ThreadDriveOutline } from "@/lib/threadGeometry";
import type { ScrewBossFields } from "@/lib/screwBoss";
import type { SnapFitFields } from "@/lib/snapFit";
import type { RibFields } from "@/lib/rib";
import type { GridfinityCompartmentLabel, GridfinityLabelCorner, GridfinityOpening, GridfinityOutlinePoint, GridfinityType, ShellEdges, ShellOpenings } from "@/types/layerling";

export type CadModifierKind = "chamfer" | "chamfillet" | "fillet" | "shell" | "deleteFace" | "offset";

export type CadModifierEdge = {
  id: number;
  owner?: number;
  points: number[];
  display: boolean;
  selectable: boolean;
  angle: number;
  boundary: boolean;
  manifold: boolean;
};

export type CadModifierQuality = "draft" | "standard" | "fine";

export type CadModifierDisplayEdge = {
  points: number[];
};

export type CadModifierPrimitivePart =
  | {
      kind: "box";
      width: number;
      depth: number;
      height: number;
      transform?: number[];
    }
  | {
      kind: "cylinder";
      radius: number;
      width: number;
      depth: number;
      height: number;
      transform?: number[];
    }
  | {
      kind: "cone";
      baseRadius: number;
      topRadius: number;
      width: number;
      depth: number;
      height: number;
      transform?: number[];
    }
  | {
      kind: "sphere";
      radius: number;
      width: number;
      depth: number;
      height: number;
      transform?: number[];
    }
  | {
      kind: "torus";
      majorRadius: number;
      minorRadius: number;
      width: number;
      depth: number;
      height: number;
      transform?: number[];
    };

/**
 * One piece of a flat outline in the shape's local X/Z plane, running from the
 * end of the previous piece (or the loop's start point) to (x, z). An arc is a
 * piece of the ellipse (cx + rx cos t, cz + rz sin t) from t = start to
 * t = end; with rx === rz it is a circular arc. A bezier is the Bezier curve
 * through its start, the control points and (x, z) - quadratic with one
 * control point, cubic with two, as a font's glyph outlines use them.
 */
export type CadModifierProfileSegment =
  | { kind: "line"; x: number; z: number }
  | { kind: "arc"; x: number; z: number; cx: number; cz: number; rx: number; rz: number; start: number; end: number }
  | { kind: "bezier"; x: number; z: number; controls: Array<{ x: number; z: number }> };

export type CadModifierProfileLoop = {
  x: number;
  z: number;
  segments: CadModifierProfileSegment[];
};

/**
 * One piece of a sweep's centre line (the bent tube). `frame` is a 3x4 matrix,
 * row by row, that places the section - drawn in the X/Z plane - at the start
 * of the piece, with local +Y the running direction; it keeps handedness. A
 * straight piece pushes the placed section `length` along that direction, a
 * bend turns it `angle` radians about `axis` through `center` (right-handed).
 * All in the frame the part's `transform` then places.
 */
export type CadModifierSweepPiece =
  | { kind: "straight"; frame: number[]; length: number }
  | { kind: "bend"; frame: number[]; center: [number, number, number]; axis: [number, number, number]; angle: number };

/**
 * A catalog shape whose body is its outline pushed straight up (or a section turned around an axis): the CAD worker
 * builds it as an exact solid (lines, arcs, flat caps) from the shape's own
 * parameters instead of sewing the display mesh back together.
 */
export type CadModifierProfilePart = {
  /**
   * "extrusion": the outline in the local X/Z plane pushed up by `height`.
   * "revolution": the loop is a half-section (x = distance from the axis,
   * z = position along it, x >= 0) turned once around the Z axis, `height`
   * long; the transform stands the axis up.
   * "sweep": the loops are a cross-section, pushed along the straight pieces
   * of `path` and turned through its bends, the pieces fused into one body;
   * `height` is the length of the centre line.
   * "loft": the loops are the section at the bottom (y = 0) and `topLoops`
   * the same section at the top (y = `height`), scaled and shifted - a
   * tapered or leaning extrusion. Each loop is joined to its partner by
   * straight lines (a ruled loft), which is exactly what the display's taper
   * and lean do between the two ends.
   * Either way `transform` places the result on the shape (for the teardrop it
   * also lays the extrusion on its side).
   */
  kind: "extrusion" | "revolution" | "sweep" | "loft";
  /**
   * Revolution only: a slotted screw hole (Discussion #1531). The half-section is turned whole at each end of a slot
   * `length` long, and the whole section, both halves, is pushed along the slot between them. The slot runs along
   * the local y axis, or along x with `alongX`, centred on the axis.
   */
  slot?: { length: number; alongX: boolean };
  /** Sweep only: the centre line, piece by piece. */
  path?: CadModifierSweepPiece[];
  /** Loft only: the section at the top, loop for loop and piece for piece the partner of `loops`. */
  topLoops?: CadModifierProfileLoop[];
  /**
   * Loft only, instead of `topLoops`: the top is this one point at `height` (a pointed pyramid). The bottom is then
   * one outline of straight lines, and every side is the flat triangle from one of its edges to the point.
   */
  apex?: { x: number; z: number };
  /**
   * Loft only, through more sections (#1034): every section up the height with its loops (outer first, the
   * opening second), piece for piece alike; `loops` is the first of them and `topLoops` the last.
   */
  through?: Array<{ y: number; loops: CadModifierProfileLoop[] }>;
  /** With `through`: straight walls between neighbouring sections instead of one smooth surface. */
  throughRuled?: boolean;
  /**
   * Loft only: the section turns this many degrees from bottom to top, evenly, around
   * `twistCenter` (which moves with the lean). The sides are then no longer ruled: the body is a
   * smooth loft through sections a few degrees apart (#184).
   */
  twist?: number;
  twistCenter?: { x: number; z: number };
  /** Degrees between two sections of a twisted loft, where the standard step is too coarse for an outline with fine teeth (a knurl). */
  twistStep?: number;
  /**
   * Loft only: the sections at the shares `t` of the way up, scaled by `sx` across and `sz` in
   * height from the shape's own section; `loops` is the first of them and `topLoops` the last - a round roof sloping or narrowing
   * along its length. Two neighbours where nothing between them curves are joined by a ruled
   * loft, the rest smoothly; a `corner` breaks the loft there, so the edge stays sharp.
   */
  sections?: Array<{ t: number; sx: number; sz: number; corner?: boolean }>;
  /**
   * Extrusion only: what the body keeps of itself inside a second prism - `loops` (one outline)
   * pushed `height` along its local y and placed by `frame` (a 3x4 matrix, row by row) in the
   * part's own frame. An upright body whose top slopes along its length (slope along) is its
   * plain extrusion trimmed by its side outline pushed across.
   */
  trim?: { loops: CadModifierProfileLoop[]; height: number; frame: number[] };
  /** Loft only: 0 to 1, how much of an S-curve the sides take between the ends instead of a straight line (#271); built like a turned loft, through sections. */
  smooth?: number;
  /** Loft only, with a twist: how far the lean moves the top; the turning centre moves along with it. */
  twistLean?: { x: number; z: number };
  /**
   * Loft only: degrees the sections tilt on the way up, evenly to the top - about the x axis
   * (the front rising) and about the z axis (the right side rising), around each section's
   * turning centre, after its twist (a transition's tilted top, #205).
   */
  tilt?: { x: number; z: number };
  /** Extrusion only: round every edge of the two flat ends by this radius (a rounded box). */
  capFillet?: number;
  /**
   * Extrusion only, with `capFillet`: the bottom end (y = 0) on its own. `capFillet` is then the top
   * end alone (0 when it stays flat); without this the two ends share `capFillet`.
   */
  capFilletBottom?: number;
  /**
   * Extrusion only, a GT2 pulley (Discussion #1319): `loops` is the toothed band alone, pushed up
   * from `teethBottom` to `teethTop`; the round discs (flanges, hub) on the y axis are joined to it
   * and the bore is cut through the whole height.
   */
  pulley?: { teethBottom: number; teethTop: number; discs: Array<{ bottom: number; top: number; radius: number }>; boreRadius: number };
  /**
   * Extrusion only: chamfer a round body at both ends at 45 degrees - keep
   * what lies within `radius` less `size` plus the distance from the nearer
   * end, measured from the axis through the outline's origin (knurling).
   * On a loft (a tapered or leaning knurl, #630) the bound narrows with the
   * body: `bottomScale` and `topScale` are the factors of the two ends and
   * `lean` is how far the top has moved sideways.
   */
  capChamfer?: { radius: number; size: number; bottomScale?: number; topScale?: number; lean?: { x: number; z: number } };
  /** The first loop is the outer boundary, any further loops are holes. */
  loops: CadModifierProfileLoop[];
  /**
   * Extrusion only: a text widened all round (#215) - its letters' own outlines, with the font's
   * curves, which the kernel moves out by `width` itself, so the walls stay planes and single
   * curves instead of the hundreds of short straight pieces `loops` (the outline the display's
   * polygon offset made, the fallback) is made of. Each region is a letter's outline with its
   * counters (none for a silhouette); the regions' wider bodies are fused. `area` is what `loops`
   * enclose, which the exact body has to agree with, or `loops` is used.
   */
  grow?: {
    width: number;
    regions: Array<{ outer: CadModifierProfileLoop; holes: CadModifierProfileLoop[] }>;
    silhouette: boolean;
    area: number;
  };
  height: number;
  transform?: number[];
  /**
   * World bounds [minX, minY, minZ, maxX, maxY, maxZ] and volume of the
   * display mesh - the exact body has to agree with them, or the worker falls
   * back to the mesh.
   */
  expected?: { bounds: number[]; volume: number };
};

/**
 * A thread, rod, screw, nut or tapped hole, as the exact body its display
 * mesh draws: the profile swept along a helix, cut to length and chamfered
 * at its ends, with its head or nut body around it. Built in the shape's own
 * frame (y up, the axis on y, the bottom at y = 0); `transform` places it.
 */
export type CadModifierThreadPart = {
  role: "rod" | "screw" | "nut" | "bore";
  /** One pitch of the profile from the crest: u in [0, 1), level 1 = major radius, 0 = minor; straight between points, as drawn, unless `curve` says otherwise. */
  profile: Array<{ u: number; level: number }>;
  /**
   * The true curve the profile points sample, where there is one: "round", the
   * cosine level = (1 + cos 2 pi u) / 2; "whitworth", arcs of `radius` (in
   * pitches) at crest and root, tangent to flanks at `halfAngle` (radians).
   * Absent: the points themselves are the profile.
   */
  curve?: { kind: "round" } | { kind: "whitworth"; radius: number; halfAngle: number };
  major: number;
  minor: number;
  pitch: number;
  /** Threads side by side (#1348), each `pitch` from the next, each climbing `pitch * starts` a turn; 1 when absent. */
  starts?: number;
  /** 1: the thread climbs as the angle from +x towards +z grows, a left-hand thread about +y; -1 the other way, a right-hand one. */
  hand: 1 | -1;
  height: number;
  /** Where the thread starts: 0, or the top of a screw head. */
  shaftBottom: number;
  /** The 45 degree chamfer at the thread ends; 0 for none. */
  chamfer: number;
  /** The chamfer at the bottom end, when the part has one (`chamferBottom`). */
  chamferLow: number;
  chamferBottom: boolean;
  /**
   * A tapered thread (NPT, #1267): every radius at height y (above the shape's bottom) is shifted
   * by `slope * (y - at)`, as the mesh draws it. Absent for a straight thread.
   */
  taper?: { slope: number; at: number };
  /** A nut body or screw head of outline tiers (#1131): square, flange, wing or star knob. It takes the place of the hexagon or head kind. */
  tiers?: ThreadOutlineTier[];
  /** Screw only. */
  head?: {
    kind: ThreadHead;
    height: number;
    /** Cylinder head radius, or the countersunk head's crown radius at y = 0. */
    radius: number;
    /** Hex head across flats. */
    acrossFlats: number;
    /** The countersunk cone's radius where it meets the shaft. */
    neckRadius: number;
    /** Radius of the flat faces when both head edges are chamfered, or 0. */
    chamferFaceRadius: number;
    /** The drive in the free head face (#1052) as its outline in the x/z plane of the shape, and its depth; 0 depth for none. */
    driveOutline?: ThreadDriveOutline;
    socketDepth: number;
    /** The round collar (#1152) on the head's shaft face, up from `height`; on an outline head it is a tier instead. */
    collar?: { radius: number; height: number };
  };
  /** Nut only: its hex across flats, and the face radius of its chamfered rims (0 for sharp). The collar (#1175) is a round part on its top face, up from the body, which is `height` less the collar. */
  nut?: { acrossFlats: number; chamferFaceRadius: number; collar?: { radius: number; height: number } };
  transform?: number[];
  expected?: { bounds: number[]; volume: number };
};

/**
 * A spring, as the exact body its display mesh draws: a round wire swept
 * along a helix about y, cut square to the wire at both ends. The centre line
 * starts on +x at y = `bottom` and climbs `span` in `turns` whole turns as the
 * angle from +x towards +z grows. Built in the shape's own frame (y up, the
 * bottom at y = 0); `transform` places it, footprint stretch included.
 */
export type CadModifierSpringPart = {
  coilRadius: number;
  wireRadius: number;
  turns: number;
  bottom: number;
  span: number;
  /** Right-hand: the wire climbs right-handed about the shape's up axis, like a usual compression spring. */
  hand: "right" | "left";
  /** The display mesh's polygon wire section as a share of the round one, which the mesh's volume is short by. */
  meshSectionShare: number;
  transform?: number[];
  expected?: { bounds: number[]; volume: number };
};

/**
 * A helical gear, as the exact body its display mesh draws: the tooth ring's
 * corners (radius and angle from +x towards +z, at the foot) turned evenly
 * by `twist` radians about y from the foot to the top, every side the ruled
 * face between the helices of its two corners; the result stretched by
 * `stretch` (x and z) as the mesh is, then the straight round bore cut
 * through it. Built in the shape's own frame (y up, the foot at y = 0);
 * `transform` places it. A herringbone gear's corners turn by half the
 * twist up to the middle and back.
 */
export type CadModifierHelicalGearPart = {
  corners: Array<{ angle: number; radius: number }>;
  /** Radians; the corners turn from +x towards +z as they rise when positive. */
  twist: number;
  /** A herringbone gear: the corners turn by half the twist up to the middle and back to where they began at the top. */
  herringbone?: boolean;
  height: number;
  stretch: { x: number; z: number };
  /** 0 for none. */
  boreRadius: number;
  transform?: number[];
  expected?: { bounds: number[]; volume: number };
};

/**
 * A Hirth joint (#1016), as the exact body its display mesh draws: the rim's
 * half width and half depth, the height, the teeth and their height at the
 * rim, and the round bore (0 for none), in the shape's own frame (y up, the
 * bottom at y = 0, centred on x and z); `transform` places it.
 */
export type CadModifierHirthPart = {
  rx: number;
  rz: number;
  height: number;
  teeth: number;
  toothHeight: number;
  boreRadius: number;
  /** Saw teeth (Discussion #1320): how far past its crest a root lies, as a share of one tooth; missing means 0.5, symmetric teeth. */
  split?: number;
  transform?: number[];
  expected?: { bounds: number[]; volume: number };
};

/**
 * A Gridfinity bin or baseplate, as the exact body its display mesh draws:
 * the size and settings it is built from (`gridfinityPlan`), in the shape's
 * own frame (y up, the bottom at y = 0, centred on x and z); `transform`
 * places it.
 */
export type CadModifierGridfinityPart = {
  width: number;
  depth: number;
  height: number;
  gridfinityType: GridfinityType;
  gridfinityLip: boolean;
  gridfinityMagnets: boolean;
  gridfinityHalfGrid?: boolean;
  gridfinityLargePlate?: boolean;
  gridfinitySwallowtail?: boolean;
  gridfinityLabelBack?: boolean;
  gridfinityLabelFront?: boolean;
  gridfinityLabelLeft?: boolean;
  gridfinityLabelRight?: boolean;
  gridfinityLabelBackWidth?: number;
  gridfinityLabelBackLength?: number;
  gridfinityLabelBackOffset?: number;
  gridfinityLabelFrontWidth?: number;
  gridfinityLabelFrontLength?: number;
  gridfinityLabelFrontOffset?: number;
  gridfinityLabelLeftWidth?: number;
  gridfinityLabelLeftLength?: number;
  gridfinityLabelLeftOffset?: number;
  gridfinityLabelRightWidth?: number;
  gridfinityLabelRightLength?: number;
  gridfinityLabelRightOffset?: number;
  gridfinityLabelCorner?: GridfinityLabelCorner;
  gridfinityLabelCornerSize?: number;
  gridfinityScoopBack?: boolean;
  gridfinityScoopFront?: boolean;
  gridfinityScoopLeft?: boolean;
  gridfinityScoopRight?: boolean;
  gridfinityScoopRadius?: number;
  gridfinityFloorHeight?: number;
  gridfinityOpenBack?: boolean;
  gridfinityOpenFront?: boolean;
  gridfinityOpenLeft?: boolean;
  gridfinityOpenRight?: boolean;
  gridfinityLipChamfer?: number;
  gridfinityWallThickness?: number;
  gridfinityPaddingBack?: number;
  gridfinityPaddingFront?: number;
  gridfinityPaddingLeft?: number;
  gridfinityPaddingRight?: number;
  gridfinityCornerRadius?: number;
  gridfinityBinCornerRadius?: number;
  gridfinityCompartmentsX?: number;
  gridfinityCompartmentsZ?: number;
  gridfinityDividerThickness?: number;
  gridfinityDividerPositionsX?: number[];
  gridfinityDividerPositionsZ?: number[];
  gridfinityCompartmentLabels?: GridfinityCompartmentLabel[];
  gridfinityOpenings?: GridfinityOpening[];
  gridfinityOpeningCorner?: GridfinityLabelCorner;
  gridfinityOpeningCornerSize?: number;
  gridfinityOutline?: GridfinityOutlinePoint[];
  /**
   * The letters on its shelves (#1308), made on the page from the fonts: for each shelf its top, and each glyph as its
   * outline and holes with the font's own curves, in the shape's x and z.
   */
  gridfinityLetters?: Array<{ top: number; glyphs: CadModifierProfileLoop[][] }>;
  transform?: number[];
  expected?: { bounds: number[]; volume: number };
};

/**
 * An enclosure part (#1246) - a screw boss, a snap-fit or a rib - as the exact body its display mesh draws: the
 * shape's own fields, from which `enclosureSolid.ts` builds the body by the same plan as the mesh, with true circles
 * where the mesh has polygons. In the shape's own frame (y up, the bottom at y = 0, centred on x and z); `transform`
 * places it. A screw boss set as a hole (`fields.hole`) is its pocket alone, as its mesh is (#1288).
 */
export type CadModifierEnclosurePart = (
  | { kind: "screwBoss"; fields: ScrewBossFields }
  | { kind: "snapFit"; fields: SnapFitFields }
  | { kind: "rib"; fields: RibFields }
) & {
  transform?: number[];
  expected?: { bounds: number[]; volume: number };
};

export type CadModifierMeshPart = {
  positions?: Float32Array;
  indices?: Uint32Array;
  brep?: string;
  /**
   * A body imported from STEP: the file's exact solid in the shape's own
   * frame, placed by `brepTransform`. positions/indices (if any) are only the
   * fallback if it cannot be restored.
   */
  step?: string;
  brepTransform?: number[];
  /** With `step`: world bounds and volume of the display mesh, which the placed body has to match. */
  expected?: { bounds: number[]; volume: number };
  /** A thread's exact body; positions/indices (if any) are only the fallback if it cannot be built. */
  thread?: CadModifierThreadPart;
  /** A spring's exact body; positions/indices (if any) are only the fallback if it cannot be built. */
  spring?: CadModifierSpringPart;
  /** A helical gear's exact body; positions/indices (if any) are only the fallback if it cannot be built. */
  helicalGear?: CadModifierHelicalGearPart;
  /** A Gridfinity bin or baseplate's exact body; positions/indices (if any) are only the fallback if it cannot be built. */
  gridfinity?: CadModifierGridfinityPart;
  /** A Hirth joint's exact body; positions/indices (if any) are only the fallback if it cannot be built. */
  hirth?: CadModifierHirthPart;
  /** A screw boss's, snap-fit's or rib's exact body; positions/indices (if any) are only the fallback if it cannot be built. */
  enclosure?: CadModifierEnclosurePart;
  primitive?: CadModifierPrimitivePart;
  /** When set, positions/indices (if any) are only the fallback if the exact body fails. */
  profile?: CadModifierProfilePart;
  hole: boolean;
  /**
   * The groups inside the treated group that this part sits in, where such a group mixes solids and holes: its
   * holes cut only the solids with the same scope (#996). Missing or empty for the treated group's own level.
   */
  scope?: number[];
};

export type CadModifierComponentMesh = {
  owner: number;
  positions: Float32Array;
  normals: Float32Array;
  indices: Uint32Array;
  triangleCount: number;
  brep: string;
  displayEdges: CadModifierDisplayEdge[];
};

export type CadModifierDeflection = { linear: number; angular: number };

/** One face of a prepared body, for Delete face (#451) and the MCP's face list. */
export type CadFaceInfo = {
  /** The face's place in the body's face list (getSubShapes order). */
  id: number;
  /** OCCT's surface kind: plane, cylinder, cone, sphere, torus, bspline, ... */
  kind: string;
  area: number;
  center: { x: number; y: number; z: number };
  /** Out of the body, for flat faces only. */
  normal?: { x: number; y: number; z: number };
  /** Twice the area over the perimeter: how narrow the face is, for the thin faces Delete face takes along. */
  width: number;
  /** The faces it shares an edge with. */
  neighbours: number[];
};

/** The prepared body's faces: each face's description and, for picking, the tessellation with the face of every triangle. */
export type CadModifierFaces = {
  list: Array<CadFaceInfo & { owner: number }>;
  mesh?: { positions: Float32Array; indices: Uint32Array; triangleFaces: Int32Array };
};

/** Faces a mesh was rebuilt with as an exact solid, by kind; facets are flat pieces of a freeform area. */
export type CadModifierExactReport = {
  plane: number;
  cylinder: number;
  cone: number;
  sphere: number;
  torus: number;
  facets: number;
  /** Share of the surface left as facets, 0 to 1. */
  facetShare: number;
  /** Faces of the finished solid. */
  faces: number;
  triangles: number;
};

export type CadModifierWorkerRequest =
  // faces: also send the body's faces (Delete face); faceMesh: with their tessellation, for picking.
  // exact: the mesh parts are to be made exact (Make exact): larger meshes and more time than the edge tool allows.
  | { type: "prepare"; requestId: number; parts: CadModifierMeshPart[]; sharpAngle: number; suppressTreatmentDetailEdges?: boolean; faces?: boolean; faceMesh?: boolean; exact?: boolean }
  | {
      type: "preview";
      requestId: number;
      // "lid" (#1154) changes nothing: it builds the exact lid for the prepared body. "exact" changes nothing either:
      // it gives back the prepared body itself, the mesh rebuilt as an exact solid (Make exact).
      kind: CadModifierKind | "lid" | "exact";
      edgeIds: number[];
      amount: number;
      quality: CadModifierQuality;
      chamferAngle: number;
      // Only for "fillet" of one edge (#687): the radius at the edge's end, `amount` the one at its start.
      endAmount?: number;
      // Only for "fillet" (#1160): a scoop cut out of the edge instead of a rounding, `amount` the radius.
      concave?: boolean;
      // Only for "shell": which faces stay open; `amount` is the wall thickness.
      shellOpenings?: ShellOpenings;
      shellEdges?: ShellEdges;
      // Only for "offset" (#919): `amount` is the distance, moved inward when this is set.
      offsetShrink?: boolean;
      // Only for "offset" (#1057): only the sides move, the body keeps its height.
      offsetSideways?: boolean;
      // Only for "deleteFace": the faces to delete, as the prepare numbered them.
      faceIds?: number[];
      // Only for "lid" (#1154): the kind, sizes, pockets and place of the lid.
      lid?: CadLidRequest;
      // The finest deflection the shape's edge-treatment history has needed
      // so far, if any - a floor beneath this operation's own deflection.
      minDeflection?: CadModifierDeflection;
      // The edges picked since the last preview that worked. When there are
      // any, the editor already knows which edge to blame on a refusal, and
      // the worker does not search for one.
      addedEdgeIds?: number[];
    }
  | { type: "dispose"; requestId: number };

export type CadModifierWorkerResponse =
  // exactReport: what the mesh parts were rebuilt from (planes, cylinders, ... and facets), when any was.
  | { type: "ready"; requestId: number; edges: CadModifierEdge[]; selectableEdgeIds: number[]; sourceType: string; faces?: CadModifierFaces; exactReport?: CadModifierExactReport }
  | {
      type: "preview";
      requestId: number;
      positions: Float32Array;
      normals: Float32Array;
      indices: Uint32Array;
      triangleCount: number;
      brep: string;
      displayEdges: CadModifierDisplayEdge[];
      components?: CadModifierComponentMesh[];
      // The deflection actually used for this operation - request.minDeflection
      // folded in, so the caller can carry it forward as the new floor.
      deflection: CadModifierDeflection;
      // Short corner edges the worker took along so a refused chamfer or fillet went through (#1178).
      cornerEdgeIds?: number[];
      /** Sharp inner corners at the ends of the picked edges, rounded or chamfered first at `amount` so they went through. */
      innerCorners?: { count: number; amount: number };
    }
  | { type: "disposed"; requestId: number }
  // failedEdgeIds: the selected edges the kernel could not treat together.
  // tightestBend: a fillet refused because a picked curve bends round the outside tighter than its radius, in mm (#1473).
  | { type: "error"; requestId: number; message: string; resetSession?: boolean; failedEdgeIds?: number[]; tightestBend?: number };
