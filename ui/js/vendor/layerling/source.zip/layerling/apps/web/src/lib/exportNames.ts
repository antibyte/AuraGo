export type ProjectExportFormat = "stl" | "3mf" | "obj" | "step" | "svg" | "png" | "lyl";

export function projectExportFileName(projectName: string, format: ProjectExportFormat) {
  const safeProjectName = projectName
    .trim()
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "-")
    .replace(/\s+/g, " ")
    .replace(/[. ]+$/g, "")
    .slice(0, 120);
  return `${safeProjectName || "layerling design"}.${format}`;
}
