import type { MessageKey } from "@/lib/messages.en";
import type { EditorHistoryEntry } from "@/lib/editorHistory";
import { localIdBase } from "@/lib/localIds";
import type { EdgeTreatmentFeature, WorkplaneShape } from "@/types/layerling";

/**
 * What one step of the history did, as a sentence key and its values, so the
 * history view can say what the arrows would undo and redo. The entries carry
 * no name for the action that made them, so the step is read from the
 * difference between the state before and the state after - which also works
 * for the history of a project saved before this existed.
 */
export type HistoryStepDescription = {
  key: MessageKey;
  values?: Record<string, string | number>;
  /** The measure the step set or changed (#1023), so "Rounded the edges of Box" can say by how much. */
  detail?: HistoryStepDetail;
};

/** A measure of a step, in millimetres or degrees; historyStepText prints it in the workspace's unit. */
export type HistoryStepDetail =
  | { kind: "length"; mm: number }
  | { kind: "size"; mm: [number, number, number] }
  | { kind: "angle"; degrees: number };

type ChangeKind = "moved" | "rotated" | "resized" | "color" | "hole" | "solid" | "renamed" | "mirrored" | "edges" | "rounded" | "chamfered" | "hollowed" | "offset" | "facesDeleted" | "hidden" | "shown" | "locked" | "unlocked" | "edited";

/** What a treatment the step added did, by the tool that made it. */
const FEATURE_KINDS: Record<EdgeTreatmentFeature["kind"], ChangeKind> = {
  fillet: "rounded",
  chamfer: "chamfered",
  chamfillet: "edges",
  shell: "hollowed",
  offset: "offset",
  deleteFace: "facesDeleted",
  // A texture is no treatment in the list; it is kept only in the history, for Change and Remove.
  surfaceTexture: "edited",
};

const POSITION_FIELDS = new Set(["x", "z", "elevation"]);
const ROTATION_FIELDS = new Set(["rotation", "rotationX", "rotationZ", "rotationPivot"]);
const SIZE_FIELDS = new Set(["size", "width", "depth", "height", "groupedBaseWidth", "groupedBaseDepth", "groupedBaseHeight"]);
const MIRROR_FIELDS = new Set(["mirrorX", "mirrorY", "mirrorZ"]);
const EDGE_FIELDS = new Set(["edgeTreatments", "edgeTreatmentHistory", "cadDisplayEdges", "cadDisplayEdgesVersion", "cadBrep", "cadBrepFrame", "sketchPose", "cadMeshDeflection"]);
/** Fields that follow from another change and say nothing of their own. */
const DERIVED_FIELDS = new Set(["formulas"]);

function sameValue(a: unknown, b: unknown) {
  if (a === b) return true;
  if (a === undefined || b === undefined || a === null || b === null) return false;
  if (typeof a !== "object" || typeof b !== "object") return false;
  return JSON.stringify(a) === JSON.stringify(b);
}

function changedFields(before: WorkplaneShape, after: WorkplaneShape) {
  const fields = new Set<string>();
  const record = (shape: WorkplaneShape) => shape as unknown as Record<string, unknown>;
  for (const key of new Set([...Object.keys(before), ...Object.keys(after)])) {
    const a = record(before)[key];
    const b = record(after)[key];
    // A flag that went from missing to false (or back) is no change.
    if ((a === undefined && b === false) || (a === false && b === undefined)) continue;
    if (!sameValue(a, b)) fields.add(key);
  }
  return fields;
}

function changeKind(before: WorkplaneShape, after: WorkplaneShape, fields: Set<string>): ChangeKind | null {
  const meaningful = [...fields].filter((field) => !DERIVED_FIELDS.has(field));
  if (meaningful.length === 0) return null;
  // One more treatment is that treatment, whatever else it rebuilt - a group treated becomes a body of its own.
  const treatments = after.edgeTreatments ?? [];
  if (treatments.length === (before.edgeTreatments?.length ?? 0) + 1) return FEATURE_KINDS[treatments[treatments.length - 1].kind] ?? "edges";
  const only = (group: Set<string>) => meaningful.every((field) => group.has(field));
  if (only(new Set(["name"]))) return "renamed";
  // Paint (paint.ts) colours parts of the body: a step of it reads as a change of colour.
  if (only(new Set(["color", "paint"]))) return "color";
  if (only(new Set(["hole"]))) return after.hole ? "hole" : "solid";
  if (only(new Set(["hidden"]))) return after.hidden ? "hidden" : "shown";
  if (only(new Set(["locked"]))) return after.locked ? "locked" : "unlocked";
  if (only(POSITION_FIELDS)) return "moved";
  if (only(new Set([...ROTATION_FIELDS, ...POSITION_FIELDS]))) return meaningful.some((field) => ROTATION_FIELDS.has(field)) ? "rotated" : "moved";
  // A resize from a handle keeps the opposite side in place, so it moves the centre too.
  if (only(new Set([...SIZE_FIELDS, ...POSITION_FIELDS])) && meaningful.some((field) => SIZE_FIELDS.has(field))) return "resized";
  if (only(new Set([...MIRROR_FIELDS, ...POSITION_FIELDS])) && meaningful.some((field) => MIRROR_FIELDS.has(field))) return "mirrored";
  if (meaningful.some((field) => field === "edgeTreatments") && only(new Set([...EDGE_FIELDS, ...SIZE_FIELDS, ...POSITION_FIELDS]))) return "edges";
  return "edited";
}

const ROTATION_ANGLE_FIELDS = ["rotation", "rotationX", "rotationZ"] as const;

/**
 * The measure of one object's change: the size a treatment was made with, how far it moved, the angle it
 * turned by about one axis, or the size it was given. Null where no single number says it.
 */
function changeDetail(before: WorkplaneShape, after: WorkplaneShape, kind: ChangeKind): HistoryStepDetail | null {
  if (kind === "rounded" || kind === "chamfered" || kind === "hollowed" || kind === "offset") {
    const amount = after.edgeTreatments?.at(-1)?.amount;
    return typeof amount === "number" && Number.isFinite(amount) ? { kind: "length", mm: amount } : null;
  }
  if (kind === "moved") {
    const mm = Math.hypot(after.x - before.x, after.z - before.z, (after.elevation ?? 0) - (before.elevation ?? 0));
    return mm > 0 ? { kind: "length", mm } : null;
  }
  if (kind === "rotated") {
    const turned = ROTATION_ANGLE_FIELDS.filter((field) => (after[field] ?? 0) !== (before[field] ?? 0));
    if (turned.length !== 1) return null;
    let degrees = ((after[turned[0]] ?? 0) - (before[turned[0]] ?? 0)) % 360;
    if (degrees > 180) degrees -= 360;
    if (degrees <= -180) degrees += 360;
    return { kind: "angle", degrees };
  }
  if (kind === "resized") return { kind: "size", mm: [after.width, after.depth, after.height] };
  return null;
}

function sameDetail(a: HistoryStepDetail | null, b: HistoryStepDetail | null) {
  if (!a || !b || a.kind !== b.kind) return false;
  const close = (x: number, y: number) => Math.abs(x - y) < 1e-6;
  if (a.kind === "angle" && b.kind === "angle") return close(a.degrees, b.degrees);
  if (a.kind === "length" && b.kind === "length") return close(a.mm, b.mm);
  return a.kind === "size" && b.kind === "size" && a.mm.every((value, index) => close(value, b.mm[index]));
}

const ONE_KEYS: Record<ChangeKind, MessageKey> = {
  moved: "historyStep.movedOne",
  rotated: "historyStep.rotatedOne",
  resized: "historyStep.resizedOne",
  color: "historyStep.colorOne",
  hole: "historyStep.holeOne",
  solid: "historyStep.solidOne",
  renamed: "historyStep.renamedOne",
  mirrored: "historyStep.mirroredOne",
  edges: "historyStep.edgesOne",
  rounded: "historyStep.roundedOne",
  chamfered: "historyStep.chamferedOne",
  hollowed: "historyStep.hollowedOne",
  offset: "historyStep.offsetOne",
  facesDeleted: "historyStep.facesDeletedOne",
  hidden: "historyStep.hiddenOne",
  shown: "historyStep.shownOne",
  locked: "historyStep.lockedOne",
  unlocked: "historyStep.unlockedOne",
  edited: "historyStep.editedOne",
};

const MANY_KEYS: Record<ChangeKind, MessageKey> = {
  moved: "historyStep.movedMany",
  rotated: "historyStep.rotatedMany",
  resized: "historyStep.resizedMany",
  color: "historyStep.colorMany",
  hole: "historyStep.holeMany",
  solid: "historyStep.solidMany",
  renamed: "historyStep.editedMany",
  mirrored: "historyStep.mirroredMany",
  edges: "historyStep.edgesMany",
  rounded: "historyStep.roundedMany",
  chamfered: "historyStep.chamferedMany",
  hollowed: "historyStep.hollowedMany",
  offset: "historyStep.offsetMany",
  facesDeleted: "historyStep.facesDeletedMany",
  hidden: "historyStep.hiddenMany",
  shown: "historyStep.shownMany",
  locked: "historyStep.lockedMany",
  unlocked: "historyStep.unlockedMany",
  edited: "historyStep.editedMany",
};

/**
 * The ids of a group's parts as they were before grouping gave them ids of
 * their own, so a part matches the object it was on the plate - and again
 * after ungrouping, which gives it yet another.
 */
function groupedBaseIds(shape: WorkplaneShape) {
  return new Set((shape.groupedShapes ?? []).map((part) => localIdBase(part.id)));
}

/** A shape's content apart from its id and where it stands: the same for a copy and its source. */
function contentSignature(shape: WorkplaneShape): string {
  const { id: _id, x: _x, z: _z, elevation: _elevation, groupedShapes, ...rest } = shape;
  return JSON.stringify({ ...rest, groupedShapes: groupedShapes?.map(contentSignature) });
}

/**
 * The objects that came in as copies of objects that were there before -
 * Duplicate, paste, an Alt-drag or a pattern - as the source each copies, or
 * null when one of them is no copy. Only shapes of the same kind and size are
 * compared in full, so a step with large meshes stays quick.
 */
function copySources(before: WorkplaneShape[], added: WorkplaneShape[]): WorkplaneShape[] | null {
  const signatures = new Map<WorkplaneShape, string>();
  const signature = (shape: WorkplaneShape) => {
    let known = signatures.get(shape);
    if (known === undefined) {
      known = contentSignature(shape);
      signatures.set(shape, known);
    }
    return known;
  };
  const sources: WorkplaneShape[] = [];
  for (const copy of added) {
    const source = before.find((candidate) => candidate.kind === copy.kind
      && candidate.width === copy.width && candidate.depth === copy.depth && candidate.height === copy.height
      && signature(candidate) === signature(copy));
    if (!source) return null;
    sources.push(source);
  }
  return sources;
}

/** How many groups are open for editing in a state, when the editor still knows; see describeHistoryStep. */
export type OpenGroupCount = (entry: EditorHistoryEntry) => number;

function describeShapes(before: WorkplaneShape[], after: WorkplaneShape[], openGroupsChange = 0): HistoryStepDescription | null {
  const beforeById = new Map(before.map((shape) => [shape.id, shape]));
  const afterById = new Map(after.map((shape) => [shape.id, shape]));
  const added = after.filter((shape) => !beforeById.has(shape.id));
  const removed = before.filter((shape) => !afterById.has(shape.id));

  if (added.length > 0 || removed.length > 0) {
    // Grouping takes the parts off the plate and puts one group in their place;
    // Done on a group open for editing does the same.
    if (added.length === 1 && removed.length > 0 && added[0].groupedShapes?.length) {
      const parts = groupedBaseIds(added[0]);
      if (removed.every((shape) => parts.has(localIdBase(shape.id)))) {
        return openGroupsChange < 0
          ? { key: "historyStep.groupClosed", values: { name: added[0].name } }
          : { key: "historyStep.grouped", values: { count: removed.length, name: added[0].name } };
      }
    }
    // Ungrouping takes a group away and puts its parts back; Edit group lays them out the same way.
    if (removed.length === 1 && added.length > 0 && removed[0].groupedShapes?.length) {
      const parts = groupedBaseIds(removed[0]);
      if (added.every((shape) => parts.has(localIdBase(shape.id)))) {
        return openGroupsChange > 0
          ? { key: "historyStep.groupOpened", values: { name: removed[0].name } }
          : { key: "historyStep.ungrouped", values: { name: removed[0].name } };
      }
    }
    // Cancel on a group open for editing puts the group back as it was.
    if (openGroupsChange < 0 && added.length === 1 && added[0].groupedShapes?.length) {
      return { key: "historyStep.groupClosed", values: { name: added[0].name } };
    }
    if (removed.length === 0) {
      const sources = copySources(before, added);
      if (sources) {
        if (sources.length === 1) return { key: "historyStep.duplicatedOne", values: { name: sources[0].name } };
        return sources.every((source) => source === sources[0])
          ? { key: "historyStep.copiesOf", values: { count: sources.length, name: sources[0].name } }
          : { key: "historyStep.duplicatedMany", values: { count: sources.length } };
      }
      return added.length === 1
        ? { key: "historyStep.addedOne", values: { name: added[0].name } }
        : { key: "historyStep.addedMany", values: { count: added.length } };
    }
    if (added.length === 0) {
      return removed.length === 1
        ? { key: "historyStep.deletedOne", values: { name: removed[0].name } }
        : { key: "historyStep.deletedMany", values: { count: removed.length } };
    }
    // A tool that groups the bodies it worked on with what it cut into them and lays something new beside them (a lid
    // with magnets: the box grouped with its pockets, the lid beside it) is named after what it added, not as a split.
    if (added.length > 1) {
      // The bodies may sit a group deeper: a box made of a solid and a hole is grouped on its own first.
      const heldIds = (shape: WorkplaneShape): string[] => (shape.groupedShapes ?? []).flatMap((part) => [localIdBase(part.id), ...heldIds(part)]);
      const holders = added.filter((shape) => shape.groupedShapes?.length && removed.every((gone) => heldIds(shape).includes(localIdBase(gone.id))));
      if (holders.length === 1) {
        const made = added.filter((shape) => shape !== holders[0]);
        return made.length === 1
          ? { key: "historyStep.addedOne", values: { name: made[0].name } }
          : { key: "historyStep.addedMany", values: { count: made.length } };
      }
    }
    if (removed.length === 1 && added.length > 1) {
      return { key: "historyStep.splitOne", values: { name: removed[0].name, count: added.length } };
    }
    return { key: "historyStep.replaced", values: { removed: removed.length, added: added.length } };
  }

  const changes: { before: WorkplaneShape; after: WorkplaneShape; kind: ChangeKind }[] = [];
  for (const shape of after) {
    const previous = beforeById.get(shape.id);
    if (!previous) continue;
    const kind = changeKind(previous, shape, changedFields(previous, shape));
    if (kind) changes.push({ before: previous, after: shape, kind });
  }
  if (changes.length === 0) {
    const reordered = before.some((shape, index) => after[index]?.id !== shape.id);
    return reordered ? { key: "historyStep.reordered" } : null;
  }
  if (changes.length === 1) {
    const [change] = changes;
    if (change.kind === "renamed") {
      return { key: "historyStep.renamedOne", values: { name: change.before.name, newName: change.after.name } };
    }
    const detail = changeDetail(change.before, change.after, change.kind);
    return { key: ONE_KEYS[change.kind], values: { name: change.after.name }, ...(detail ? { detail } : {}) };
  }
  const kind = changes.every((change) => change.kind === changes[0].kind) ? changes[0].kind : "edited";
  // Several objects changed alike - moved together, rounded with one radius - share their measure.
  const details = kind === "edited" ? [] : changes.map((change) => changeDetail(change.before, change.after, kind));
  const detail = details.length > 0 && details.every((entry) => sameDetail(entry, details[0])) ? details[0] : null;
  return { key: MANY_KEYS[kind], values: { count: changes.length }, ...(detail ? { detail } : {}) };
}

function describeNotes(before: EditorHistoryEntry, after: EditorHistoryEntry): HistoryStepDescription | null {
  const beforeNotes = before.notes ?? [];
  const afterNotes = after.notes ?? [];
  if (sameValue(beforeNotes, afterNotes)) return null;
  const beforeIds = new Set(beforeNotes.map((note) => note.id));
  const afterIds = new Set(afterNotes.map((note) => note.id));
  const added = afterNotes.filter((note) => !beforeIds.has(note.id));
  const removed = beforeNotes.filter((note) => !afterIds.has(note.id));
  const isPoint = (note: { kind?: string }) => note.kind === "point";
  if (added.length > 0 && removed.length === 0) {
    return { key: added.every(isPoint) ? "historyStep.pointAdded" : "historyStep.noteAdded" };
  }
  if (removed.length > 0 && added.length === 0) {
    return { key: removed.every(isPoint) ? "historyStep.pointRemoved" : "historyStep.noteRemoved" };
  }
  const changed = afterNotes.filter((note) => beforeIds.has(note.id));
  return { key: changed.length > 0 && changed.every(isPoint) && added.length === 0 ? "historyStep.pointChanged" : "historyStep.noteChanged" };
}

/**
 * What the step from `before` to `after` did. Without a state before it, the
 * entry is where the history begins. `openGroups` tells opening and closing a
 * group for editing apart from ungrouping and grouping, which change the
 * shapes the same way; without it (or for a history loaded from a file, which
 * does not keep which groups were open) they read as the latter.
 */
export function describeHistoryStep(before: EditorHistoryEntry | undefined, after: EditorHistoryEntry, openGroups?: OpenGroupCount): HistoryStepDescription {
  if (!before) return { key: "historyStep.start" };
  const openGroupsChange = openGroups ? Math.sign(openGroups(after) - openGroups(before)) : 0;
  const shapes = describeShapes(before.shapes, after.shapes, openGroupsChange);
  if (shapes) return shapes;
  const notes = describeNotes(before, after);
  if (notes) return notes;
  if (!sameValue(before.placementWorkplane, after.placementWorkplane)) return { key: "historyStep.workplane" };
  return { key: "historyStep.changed" };
}

/** The steps the arrows of the History view would undo and redo from the state at `index`. */
export function historyStepsAround(entries: EditorHistoryEntry[], index: number, openGroups?: OpenGroupCount) {
  return {
    last: index > 0 ? describeHistoryStep(entries[index - 1], entries[index], openGroups) : null,
    next: index < entries.length - 1 ? describeHistoryStep(entries[index], entries[index + 1], openGroups) : null,
  };
}
