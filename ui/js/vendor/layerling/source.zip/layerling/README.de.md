<div align="center">
  <table>
    <tr>
      <td width="145" align="center">
        <img src="apps/web/public/assets/layerling/layerling-logo.svg" width="110" alt="layerling-Logo">
      </td>
      <td>
        <h1 align="right">layerling</h1>
        <h3 align="right">Einfaches 3D-CAD für den 3D-Druck</h3>
        <p align="right">
          Form hinstellen, Aussparung hineinschneiden, Kante brechen, drucken. Im Browser, ohne Konto und ohne CAD-Vorkenntnisse.
        </p>
      </td>
    </tr>
  </table>

  <p>
    <a href="LICENSE"><img alt="GNU-AGPLv3-Lizenz" src="https://img.shields.io/badge/Lizenz-AGPLv3-663399"></a>
    <img alt="Kein Konto nötig" src="https://img.shields.io/badge/ohne%20Konto-nichts%20anzumelden-dd7906">
    <img alt="Für den 3D-Druck gemacht" src="https://img.shields.io/badge/gemacht%20für-3D--Druck-ff9e2c">
    <a href="#layerling-mcp-skill"><img alt="Von einer KI steuerbar" src="https://img.shields.io/badge/KI--steuerbar-MCP--Server-16c0d4"></a>
  </p>

  <p><a href="README.md">English</a> · <strong>Deutsch</strong> · <a href="README.es.md">Español</a> · <a href="README.nl.md">Nederlands</a> · <a href="README.ar.md">العربية</a> · <a href="README.ja.md">日本語</a> · <a href="README.zh-cn.md">简体中文</a> · <a href="README.zh-tw.md">繁體中文</a></p>
</div>

<p align="center">
  <img src="docs/media/screenshot-de.png" width="770" alt="layerling im Browser">
</p>

<p align="center"><em>layerling im Browser</em></p>

<p align="center"><a href="https://layerling.com/anleitung/index.html"><strong>Anleitung</strong></a>, Schritt für Schritt und mit Bildern</p>

## Für wen das gedacht ist

Du hast einen 3D-Drucker. Du willst ein Teil, das passt – keine Laufbahn als CAD-Konstrukteur.

layerling arbeitet so, wie du ohnehin denkst: Form auf die Platte stellen, auf Maß ziehen, eine zweite Form zur Aussparung erklären, beides gruppieren, exportieren, drucken. Es gibt nichts zu lernen, bevor du anfängst, und **nichts anzumelden** – Seite öffnen und bauen. Deine Entwürfe bleiben standardmäßig in deinem eigenen Browser: kein Konto, keine Cloud, nichts wird irgendwohin hochgeladen. Wenn du eine eigene Instanz betreibst, können sie stattdessen in einem Ordner auf deinem Server liegen, sodass jedes Gerät im Haus dieselben sieht.

### Von Tinkercad umgestiegen?

layerling ist ein Stück weiter als Tinkercad in Richtung Fusion 360 und wird genauso bedient: Du wirst alles wiedererkennen – die Platte, die Formen, Körper und Aussparung (dort Solid und Hole), Gruppieren und Auflösen, Bündeln, mit Alt eine Kopie ziehen –, aber es hört nicht dort auf, wo Tinkercad aufhört. Das wartet hier auf dich, was du dort vermisst hast:

- **Kanten fasen und verrunden.** Kante auswählen und brechen oder abrunden – das, wonach am häufigsten gefragt wird, sobald ein gedrucktes Teil fertig aussehen oder irgendwo hineinpassen soll. Bearbeitete Kanten bleiben veränderbar: Du nimmst Fase oder Rundung jederzeit wieder weg oder änderst mit „Ändern“ ihren Wert auf denselben Kanten.
- **Aushöhlen, Teilen, Skizzen, Gewinde.** Körper mit gleichmäßiger Wand aushöhlen, mit einer Ebene teilen, Skizzen mit genauen Längen und Winkeln ziehen oder drehen, dazu Schrauben, Muttern und Gewindelöcher.
- **Muster und Wickeln.** Eine Form in Reihe, im Raster aus Spalten und Reihen, im Kreis oder als Spirale wiederholen, oder ein Muster und Schrift um einen Zylinder wickeln.
- **Lochmuster.** Eine ebene Fläche oder die runde Wand eines Zylinders oder Rohrs anklicken und runde, quadratische, rechteckige, sechseckige oder Langlöcher darauf verteilen, im Raster oder versetzt, mit Abstand, Rand und Tiefe - Lüftungsgitter, Lautsprecher und Körbe in einem Schritt. Oder einen Kranz von Schraubenlöchern entlang der Kante setzen, auf Wunsch mit Stufen- oder Senkbohrung, oder eine eigene Form darüber wiederholen, Nieten oder ein Riffelblech.
- **Um Prozent skalieren.** Ein oder viele Teile um einen Prozentwert größer oder kleiner machen - zusammen, so dass die Anordnung mitwächst, oder jedes an seinem Platz.
- **Größe angleichen.** Mit Alt auf einem Ausrichtungspunkt werden die Teile gestreckt statt verschoben: bis an die Kante eines anderen Teils oder auf seine Breite, Länge oder Höhe - etwa um einen Quader gegen einen gleich großen Zylinder zu tauschen.
- **Gleiche Abstände.** Verschieden große Teile so verteilen, dass zwischen ihnen überall derselbe Abstand ist - zwischen den beiden äußeren, auf einem Brett mit demselben Abstand zum Rand oder Reihe für Reihe, etwa für ein Steckpuzzle; oder den Abstand eintippen.
- **Messen und hineinschauen.** Maßband, Lineale, eine Schnittansicht, die das Modell aufschneidet, und ein Verlauf-Schieber zum Zurückschauen.
- **Echte Geometrie darunter.** layerling führt exakte CAD-Körper mit, nicht nur ein Dreiecksnetz. Eine verrundete Kante bleibt deshalb eine verrundete Kante – bis in eine STEP-Datei für ein vollwertiges CAD.

Ein vollständiges CAD-Paket ist es nicht: Es gibt keine parametrische Zeitleiste und keine Baugruppen. Dafür kannst du es **selbst betreiben**: als App installieren (dann startet es auch ohne Internet) oder eine eigene Kopie unter Windows, auf einer NAS oder einem Heimserver laufen lassen – siehe [Loslegen](#loslegen).

> **Eine KI kann mitbauen.** layerling bringt einen MCP-Server mit. Ein KI-Client wie Codex oder Claude sieht damit einen
> offenen Editor-Tab und arbeitet darin: Formen anlegen, Maße ändern, gruppieren, schneiden, Kanten verrunden, die Szene
> auslesen, Bilder der Ansicht aufnehmen. Du beschreibst das Teil, die KI baut es, du siehst zu und greifst jederzeit ein.
> Das läuft lokal, ohne dass etwas den Browser verlässt – wie das eingerichtet wird, steht unter
> [layerling-MCP-Skill](#layerling-mcp-skill).

## Was es kann

### Bauen

- **Eine echte Bauplatte** – Raster, Einrasten, Griffe zum Verschieben, Skalieren und Drehen, und ein Feld mit den genauen Zahlen, wenn du sie brauchst.
- **Position eintippen** – die Karte Position setzt einen Körper auf genaue X-, Y- und Z-Werte, gemessen von seiner Mitte oder von seiner linken und vorderen Kante, und Teile lassen sich wie bei Tinkercad neben der Platte parken.
- **Achsenpfeile** – rote, grüne und blaue Pfeile am vorderen linken Eck der Platte zeigen X, Y und Z so, wie die Zahlen zählen, wie bei Bambu Studio und OrcaSlicer; in den Einstellungen abschaltbar.
- **Drehpunkt, der bleibt** – ein Drehpunkt für einen Körper bleibt bei diesem Körper: Er wandert, dreht und skaliert mit, wird gespeichert und lässt sich als X, Y und Z eintippen oder mit der Maus ziehen, wobei er an Ecken und Kantenmitten einrastet, mit Shift an der Mitte einer Fläche (Achse eines Zapfens, Spitze eines Kegels, auch durch transparente Körper hindurch) – für Scharniere und Gelenke.
- **Licht und Schatten nach Geschmack** – Kontrast der Schattierung, Stärke und Weichheit der Schatten sowie Richtung und Höhe des Lichts, bis senkrecht von oben wie bei Tinkercad, alles in den Einstellungen. Ein Knopf „Wie Tinkercad“ stellt Farben, Raster und Licht auf einmal so ein wie dort, und die kräftigen Rasterlinien kommen auf Wunsch jeden Zentimeter in eigener Farbe.
- **Schnellmodus** – für langsamere Rechner: ein Schalter in den Einstellungen schaltet Schatten, Kantenlinien und das Nachlaufen der Kamera ab und zeichnet die Ansicht in Bildschirmauflösung; das Nachlaufen lässt sich auch einzeln abschalten, dann steht die Ansicht sofort.
- **Flächen aneinanderlegen und Winkel sehen** – das Werkzeug legt eine Fläche eines Teils an eine Fläche eines anderen, berührend oder bündig, auf Wunsch mit Abstand, bringt ein Loch oder einen Zapfen auf die Achse eines anderen Lochs oder verschiebt ein Teil gerade, sodass eine Ecke oder ein Bezugspunkt auf einem Punkt eines anderen Teils landet, entlang X, Y und Z oder nur einzelner Achsen, und dreht es mit einem zweiten und dritten Punktpaar in Lage, wie beim Ausrichten an drei Punkten; ein gedrehter Körper zeigt seine Winkel um X, Y und Z unter der Auswahl, und die Karte „Drehung“ in seinen Einstellungen nimmt sie als Zahlen.
- **Fangen an anderen Formen** – beim Verschieben rastet eine Form mit Kante oder Mitte an Kanten und Mitten der Formen ringsum ein, eine Hilfslinie zeigt woran. So sitzen Teile bündig, ohne Zahlen zu tippen. Auch die Mitte der Arbeitsebene zählt, für ein Teil genau in der Plattenmitte. Alt während des Ziehens hält das kurz an; Umschalt hält die Bewegung auf einer Achse, und mit Alt zu Beginn ziehst du wie in Tinkercad eine Kopie.
- **Auf Flächen absetzen** – wie Cruise in Tinkercad: Eine neue Form legt sich auf die Fläche unter dem Zeiger, auch auf eine schräge, und C nimmt die Auswahl auf und setzt sie so auf eine andere Fläche. Mit gedrückter Umschalttaste beim Absetzen sinkt sie stattdessen ein, aufrecht und oben bündig mit der Fläche - etwa für eine Senkung oder eine Stufenbohrung.
- **Bezugspunkte** – Körper mit der rechten Maustaste anklicken und Mitte, Ecken oder Kantenmitten mit Punkten markieren, die nichts druckt und an denen gezogene Formen einrasten; Punkte lassen sich ziehen oder per Koordinate eintippen und werden mit dem Entwurf gespeichert. Das Maßband kann die Mitte einer Messung markieren, etwa den Mittelpunkt einer runden Bohrung.
- **Winkelmesser** – der Winkelmesser in der Ansichtsleiste misst den Winkel an einer Ecke aus drei Klicks oder zwischen zwei ebenen Flächen (eine 45°-Fase zeigt 45° · 135°); er rastet wie das Maßband an Ecken und Kanten ein und folgt den Körpern.
- **Notizen, die die KI liest** – hake an einer Notiz *Für die KI* an, und ein KI-Agent an der MCP-Brücke nimmt sie als Auftrag auf: Er liest die Notiz, erledigt die Arbeit und antwortet unter deinem Text. Er kann auch eigene Notizen ans Modell setzen, um an einer Stelle etwas zu fragen oder zu melden. Bittest du ihn, auf deine Notizen aufzupassen, wartet er auf sie (`layerling_wait_for_notes`): Jeder Auftrag wird aufgegriffen, sobald du das Häkchen setzt, ohne Umweg über das Fenster des Agenten.
- **Interaktive Hilfe** – mit Umschalt+F1 oder dem Fragezeichen im Bereich Hilfe einschalten und dann einen Knopf, ein Feld oder ein Fenster anklicken: Ein kleines Fenster zeigt das passende Stück der Anleitung und öffnet sie auf Wunsch.
- **Befehlssuche** – mit Strg+K ein Werkzeug, eine Form oder einen Befehl eintippen („Verrunden“, „Spiegeln“, „Zylinder“) und direkt dorthin springen; sie versteht deutsche und englische Wörter und zeigt die Tastenkürzel dazu.
- **Eigene Tasten** – jeden Befehl der Befehlssuche im Fenster „Tastenkürzel“ auf eine eigene Taste legen: Zentrieren, die Formenauswahl oder die Lieblingsform liegen dann eine Taste entfernt.
- **Eigenes Menüband** – Gruppen und Knöpfe, die du nie brauchst, in den Einstellungen (Darstellung) aus dem Menüband nehmen; Befehlssuche und Tasten führen sie weiter aus, und die Reihenfolge des Menübands bleibt gleich.
- **Verlaufsansicht** – mit einem Schieber auf jeden früheren Stand des Projekts zurückschauen, ohne etwas zu ändern; diesen Stand exportieren oder als neues Projekt anlegen. Von @rmpel. Rückgängig und Wiederholen nennen im Tooltip den Schritt, den sie zurücknehmen, mit seinem Maß („Kanten von Box gerundet (5 mm)“), und eine Liste in der Verlaufsansicht nennt jeden Schritt, um mit einem Klick zu einem davon zu springen.
- **Millimeter oder Zoll** – mit Imperial erscheinen alle Maße in Zoll, als Bruch wie in Tinkercad (1 5/8) oder als Dezimalzahl, das Raster rastet von 1/64 bis 1 Zoll, und das Gitter der Platte ist in Zoll gezeichnet.
- **Die Platte deines Druckers** – wähl einen von über 230 gängigen Druckern, dann bekommt die Platte seine Größe – rund bei einem Delta-Drucker wie einem FLSun. Name und Bauraum stehen in der Ecke der Arbeitsfläche (ein Schalter in den Einstellungen blendet das und den Namen des Entwurfs aus), und eine Warnung erscheint, wenn ein Körper über den Rand ragt.
- **Mehrere Druckplatten** – ein Entwurf, der mehr enthält, als auf eine Platte passt, bekommt Platten nebeneinander, so groß wie die Arbeitsfläche: Ein Körper gehört zu der Platte, auf der er steht, „Auf Platten verteilen“ legt die Teile Reihe für Reihe aus und fügt Platten hinzu, jede Platte wird für sich gegen den Drucker geprüft, und der Export schreibt eine Platte, alle oder je Platte eine Datei in einer ZIP, um sie nacheinander zu drucken.
- **Überhänge und Filament** – „Überhänge zeigen“ schraffiert jede Fläche, die steiler als 45° (oder der Winkel deines Druckers) überhängt und Stützen bräuchte, und das Exportfenster nennt Volumen, Gewicht und Meter Filament, bevor du slicst.
- **Formen-Bibliothek** – Quader, Zylinder, Kapseln (auf Wunsch mit einem kleineren Ende, etwa für eine Riemenabdeckung), Kugeln, Kegel, gebogene Kegel (wie eine Trompete oder eine Kuppel), Pyramiden, Keile, Text, Dächer, Halbkugeln, Paraboloide, Tori, Rohre, Übergänge (Loft) von einem Umriss zum anderen, etwa eckig auf rund, auch verdreht oder mit geneigtem oberen Ende oder durch bis zu zwölf Querschnitte dazwischen, mit oder ohne Wand, Mehrkante von drei bis vierundzwanzig Seiten, Schrauben- und Flachfedern (mit runden, Zickzack- oder eckigen Wellen und Öse oder Lasche an den Enden), ein druckbares Scharnier (mit Schraubenlöchern oder als Fingerscharnier), Schraubdome für Einschmelzmuttern oder Schneidschrauben (M2 bis M5, #2-56 bis 1/4-20), Schnapphaken mit ihrer Raste, Rippen und Knotenbleche, Gridfinity-Behälter und -Bodenplatten, Rändelungen für Griffe (gerade, gekreuzt oder rund), Anschlussöffnungen für USB-C-, Micro-USB-, USB-A-, HDMI- (auch Mini und Micro), DisplayPort- und RJ45-Buchsen, die XT30-, XT60-, MT60- und MPX-Stecker von Modellakkus, Anderson-Powerpole-Blöcke mit 1 bis 4 Polen und die serielle D-Sub-9-Schnittstelle samt Schraublöcher in einer Gehäusewand, bei Bedarf mit zusätzlichem Spiel, SBC-Platinen in echter Größe, um ein Gehäuse darum zu bauen (Raspberry Pi 5, 4, 3 B+ und Zero 2 W, BIGTREETECH Pi; als Aussparung gruppiert schneiden sie die Öffnungen für ihre Anschlüsse) und mehr.
- **Vasen, Töpfe und Lampenschirme** – eine eigene Form Vase: Körperform, Querschnitt (auch selbst gezeichnet) mit einem zweiten, in den er übergeht, Verdrehung, Muster, Abflusslöcher, Fuß, Untersetzer und Deckel, massiv für den Vasenmodus des Slicers oder hohl. Ein Teekannendeckel ist das Oberteil der Vase selbst, Rillen und Verdrehung laufen über die Fuge weiter. Von @marcus040473.
- **Gewinde, die passen** – Gewindestangen, Schrauben mit Zylinder-, Senk-, Sechskant-, Vierkant-, Flansch- oder Flügelkopf oder Sterngriff und Innensechskant, Torx, Kreuzschlitz, Schlitz oder Robertson-Vierkant (Kopfdurchmesser, Antriebsgröße und -tiefe frei einstellbar, auf Wunsch mit einem Bund zwischen Kopf und Gewinde oder oben auf einer Mutter), Sechskant-, Vierkant-, Flansch- und Flügelmuttern und Sterngriffmuttern, Unterlegscheiben nach ISO 7089, Rosetten für Senkschrauben und Gewindelöcher. Stufen- und Senkbohrung übernehmen Schaft und Kopf aus einer Schraubengröße (ISO 273, DIN 974-1, ISO 15065), ein Sackloch kann in einer Bohrerspitze enden (118° oder ein eigener Winkel, die Tiefe wie in einer Zeichnung bis zum Absatz gemessen), und ein Sechskant wird zur Tasche für eine Mutter nach ISO 4032. M2 bis M12 liegen bereit, dazu UNC und UNF von #4 bis ein Zoll und die Whitworth-Rohrgewinde G1/16 bis G4 (ISO 228-1) und die kegeligen NPT-Rohrgewinde 1/16" bis 4" (ASME B1.20.1); Durchmesser und Steigung lassen sich auch frei wählen, Linksgewinde ebenso, und bis zu acht Gänge für eine Trapezspindel wie T8x8. Bei einer Zoll- oder G-Größe fragt das Feld nach Gängen je Zoll statt nach Millimetern. Die Enden bekommen auf Wunsch eine Fase, und das Gewindeloch ist eine Aussparung: in ein Teil ziehen, gruppieren, fertig.
- **Zahnräder, die ineinandergreifen** – Stirn-, Schräg- und Kegelräder, Hohlräder und Zahnstangen mit Evolventenzähnen, eingestellt über Modul und Zähnezahl wie in einem Zahnradgenerator, mit Eingriffswinkel und Spiel für den Druck - oder mit runden Zähnen, gutmütig bei kleinen gedruckten Rädern und als Griff an Drehknöpfen. Zwei Räder auswählen, und das Eigenschaftenfeld nennt den Achsabstand, bei dem sie ineinandergreifen.
- **Hirth-Verzahnung** – eine Scheibe mit V-förmigen Zähnen, die strahlenförmig von der Mitte ausgehen: Eine umgedrehte Kopie greift in jedem Zahnschritt hinein und zentriert sich selbst, für verstellbare Gelenke, Stativköpfe und Rastknöpfe. Zähnezahl, Zahnhöhe (auf Wunsch bis zum Boden) und Bohrung sind einstellbar, die Zähne symmetrisch oder als Sägezahn wie bei einer Ratsche, die steile Flanke bis 90° auf der einen oder anderen Seite; sie ist ein exakter Körper für die Kantenwerkzeuge und STEP.
- **GT2-Riemenscheiben** – eine Zahnriemenscheibe für einen 2-mm-GT2-Riemen, mit der echten GT2-Zahnlücke aus Bögen. Zähnezahl (jede von 10 bis 200, nicht nur die Größen, die es zu kaufen gibt), Riemenbreite, Bordscheiben, Nabe und Bohrung sind einstellbar; der Durchmesser folgt aus den Zähnen. Sie ist ein exakter Körper für die Kantenwerkzeuge und STEP.
- **Körper und Aussparungen** – Formen zu Schneidwerkzeugen erklären und zur fertigen Geometrie gruppieren. „Gruppe bearbeiten“ (**E**) legt die Teile einer Gruppe einzeln hin und rechnet sie mit „Fertig“ neu – auch eine Gruppe in einer Gruppe, so tief der Entwurf geht.
- **Mehrfarbige Gruppen** – eine Gruppe kann jedes Teil in seiner eigenen Farbe zeigen, auch nachdem Aussparungen hineingeschnitten wurden, und der 3MF- oder OBJ-Export behält diese Farben, so dass der Slicer die Teile Filamenten zuordnen kann.
- **Bündeln** – Strg+B hält Teile zusammen wie das Bündel in Tinkercad: Sie bewegen, drehen und skalieren sich gemeinsam, behalten aber ihre Farben und bleiben im Export getrennte Körper – praktisch für den Mehrfarbdruck.
- **Schnittmenge** – nur das behalten, wo sich die ausgewählten Körper und Aussparungen überlappen.
- **Hülle** – die gewählten Formen in ihre konvexe Hülle packen, den kleinsten Körper ohne Dellen um alle: Eine Halbkugel auf einem Zylinder wird zur Kuppel, vier Pfosten zu einem Kasten mit runden Ecken. Aussparungen in der Auswahl werden danach herausgeschnitten.
- **Ausstechform** – aus einem kleinen Fenster eine Wand und ein flacher Rand um den Umriss einer Skizze oder SVG, oder um das, worauf eine Form steht; das Innere eines e oder a bekommt eine eigene Wand, gehalten von Stegen am Rand oder einer Platte über den ganzen Umriss, mit kleinen Kehlen, damit dünne Teile nicht abbrechen, und niedriger gestellt drückt sie eine Schrift nur in den Teig, statt sie auszustechen. Der Umriss wird gespiegelt, damit Schrift und Logos richtig herum aus dem Teig kommen, und die Wand läuft oben auf eine schmale Schneidkante zu. Wanddicke, Schneidkante, Höhe und Rand sind die Füllarten der Skizze, jedes lässt sich danach ändern.
- **Flexi-Gelenke** – einen flachen, selbst gezeichneten Körper, etwa einen Fisch, eine Schlange oder einen Drachen, in Glieder teilen, mit einem mitgedruckten Gelenk an jedem Schnitt: ein senkrechter Knöchel mit 45°-Kegeln in einer Fassung des nächsten Glieds, sodass sich die Figur nach dem Druck bewegt, ohne Stützen und ohne Zusammenbauen. Zahl der Gelenke, Spiel, Schwenkwinkel und Gelenkgröße sind einstellbar. Oder die Glieder klappen stattdessen nach oben und unten, wie bei einem Flexi-Schlüsselanhänger: Jeder Schnitt wird ein flaches Scharnier aus Knöcheln mit Kegeln, quer durch den Körper auf halber Höhe.
- **Übergang aus Skizzen** – zwei Skizzen oder importierte SVGs werden ein genauer Körper, unten der Umriss der unteren, oben der der oberen, dazwischen gerade Wände: ein Trichter, ein Übergang von eckig auf rund oder aus zwei Ringen ein sich verjüngender Rahmen. „Gruppe bearbeiten“ öffnet die beiden Skizzen wieder.
- **Teilen** – Körper oder Aussparungen mit einer Ebene in zwei schneiden; ein ausgehöhlter Körper behält seinen Hohlraum. Gedreht schneidet die Ebene schräg; am Pfeil ziehen verschiebt sie, und mit „Fläche wählen“ legst du sie auf eine beliebige Fläche.

### Bearbeiten

- **Kanten fasen und verrunden** – jede Kante eines Körpers brechen oder abrunden, eine gerade Kante auch konkav als Hohlkehle ausschneiden wie die ausgehöhlten Ecken einer Box, und später wieder zurücknehmen oder ändern.
- **Skizzen** – Umrisse aus Linien, Kurven und fertigen Formen zeichnen, mit Stift, Finger oder Maus freihand zeichnen (die Linie wird zu wenigen Punkten, die sich bearbeiten lassen), Linien schon beim Zeichnen nach Länge und Winkel setzen („50<30“, Umschalt rastet in 15°-Schritten ein), Längen, Winkel, Größen und die Lage eines ausgewählten Umrisses, Punkts oder Kurvengriffs eintippen (Rechnungen wie „60+12,5“ gehen in jedem Zahlenfeld), Ecken runden oder fasen, an den Umrissen anderer Körper einrasten, Hilfslinien zum Einrasten ziehen und daraus exakte Körper ziehen, drehen oder an einem Pfad entlangziehen. Eine Drehung mit Steigung windet den Umriss als einen durchgehenden Strang zur Schraubenlinie statt zu Ringen, wie Filament auf einer Spule. Eine Skizze lässt sich auch als Kontur bauen: Ein geschlossener Umriss wird ein Rahmen, innen, außen oder mittig auf der Linie, eine offene Linie ein Streifen mit flachen, eckigen oder runden Enden. Eine Zeichnung oder ein Foto unter der Skizze wird mit einem Klick zu Skizzenlinien nachgezeichnet, der dunkle oder der helle Teil, bei einer Schwelle, die du einstellst.
- **Aushöhlen** – aus einem Körper Wände gleicher Stärke machen, auf jeder gewünschten Seite offen (oben, unten, vorne, hinten, links, rechts, beliebig kombiniert) oder ganz geschlossen – für Dosen, Becher und Gehäuse.
- **Gefälle und Zulaufen in der Länge** – die Oberseite von Quader, Zylinder, Vieleck, Rohr, Keil oder rundem Dach zu einem Ende hin abfallen lassen oder die Seiten aller außer dem Rohr zu einem Ende hin zusammenlaufen lassen, gerade oder gewölbt, per Zahl oder mit einem Punkt am Ende: ein Dach, das in der Länge abfällt, eine Rampe, ein schräg abgeschnittenes Rohrende, ein Bootsbug. Ein Gefälle bleibt exakt für Fasen, Verrundungen und STEP, ebenso ein zulaufender Quader, Keil oder rundes Dach. Von @plazmabokor.
- **Deckel** – der Deckel für eine Kiste, einen Topf oder eine Schale, die oben offen ist, aus ihrem eigenen Umriss, rund oder eckig: eingesteckt, übergestülpt, beidseitig um die Wand greifend wie bei einer Frischhaltedose oder flach aufgelegt, mit strammer, normaler oder lockerer Passung (0,1, 0,2 oder 0,3 mm je Seite) oder eigenem Spalt, Deckeldicke sowie Tiefe und Wand der Lippe. Er liegt danach neben dem Körper, umgedreht mit der Platte nach unten, druckbar ohne Stützen.
- **Versetzen und Ausschneiden** – einen exakten Körper an allen Flächen um 0,01 bis 10 mm wachsen oder schrumpfen lassen, oder nur seitlich, sodass er seine Höhe behält, für das Spiel einer Presspassung oder eines Schnappverschlusses, oder ein Teil in einem Schritt mit Spiel ringsum aus einem anderen ausschneiden, wobei das Teil stehen bleibt.
- **Stanzen** – den Umriss eines Körpers entlang X, Y oder Z gerade durch einen anderen schneiden, egal wo der Stempel davor steht: die Silhouette einer Teekanne durch ein Schild, ein Logo durch einen Deckel. Der Stempel bleibt zum Verschieben und Wiederverwenden, ein Spiel lässt ein gedrucktes Teil hindurch, und die Öffnung ist ein exakter Skizzenkörper.
- **Spiel prüfen** – vor dem Druck von Teilen, die sich bewegen sollen, einem mitgedruckten Scharnier, einer Flexi-Figur, einem Deckel in seiner Dose: die Auswahl oder alle sichtbaren Objekte paarweise prüfen, ob sie sich überschneiden, berühren, zu eng oder in Ordnung sind gegen ein Mindestspiel, das du festlegst, zwischen den Schichten oder nebeneinander; ein Klick auf ein Paar zeigt die Stelle. Von @marcus040473.
- **Stützrippe** – ein Teil schräg auf einer Kante drucken, ohne die Stützen des Slicers: die untere Fläche anklicken, und eine dünne Rippe steht mit etwas Abstand darunter auf einem ovalen Fuß, mit Brücken von genau einer Schicht Höhe und einer Bahn Breite, die das Teil halten und sich danach abbrechen lassen; Düse und Schichten wie im Slicer.
- **Schablonenstege** – eine Schablone mit durchgehendem Text drucken: Die Mitte von Buchstaben wie o, a und b bekommt kleine Stege zur Platte, so breit und hoch, wie du willst (bündig unten, in der Mitte oder oben), mit der Platte gruppiert als gewöhnliche Quader, die du verschieben oder löschen kannst. Nach einer Textänderung einfach noch einmal ausführen, dann entstehen die Stege neu.
- **Oberflächentextur** – ein Relief auf jeden Körper legen, für Griff oder Aussehen: Rillen, Rändel, Waben, Noppen, Voronoi-Zellen, Ziegel, Strick, Seil, Korbgeflecht, Carbon, Baumrinde, Holzmaserung, Risse, ein Bild als Höhenkarte, gekachelt oder einmal aufgeprägt, oder Text, rund um runde Körper oder flach entlang einer Achse. Bis zu sechs Muster auf einem Körper, jedes auf eigenen Flächen: Ziegel an den Wänden und Rändel oben. Für einen Druck in zwei Farben wird das Muster auf Wunsch ein eigenes Teil in eigener Farbe. Von @marcus040473.
- **Fläche löschen** – die Flächen einer Verrundung, eines Lochs oder eines Zapfens anklicken und löschen: Die Flächen ringsum wachsen und schließen die Lücke, und der Körper bleibt exakt für weitere Verrundungen und den STEP-Export.
- **Eigene Formen** – Körper, die du immer wieder brauchst, oben in der Formenliste ablegen und per Klick oder Ziehen in jeden Entwurf setzen; im Browser oder, mit dem Serverspeicher, auf dem Server für jedes Gerät. „Alle sichern“ nimmt sie mit.
- **Lochmuster** – eine ebene Fläche eines Körpers oder die runde Wand eines Zylinders, Rohrs oder einer Bohrung perforieren (jedes Loch zeigt auf die Achse, die Reihen gehen ganz herum): Fläche anklicken, runde, quadratische, rechteckige, sechseckige oder Langlöcher wählen, Größe, Abstand, Raster, versetzt oder als Kranz am Rand (nach Abstand oder Anzahl, ein Loch auf jeder Ecke), einfache Löcher, Stufen- oder Senkbohrungen (mit metrischen Schraubengrößen) oder eine eigene Form aus der Szene (Nieten, Riffelblech, aufgesetzt oder eingeschnitten), Rand zur Kante und Tiefe (durch das ganze Teil oder ein Maß) einstellen und die Löcher vor dem Erzeugen als Vorschau sehen. Sie bleiben normale Aussparungen, mit dem Körper gruppiert, und lassen sich durch Auflösen der Gruppe wieder freigeben.
- **Fläche** – eine ebene Fläche eines Körpers herausziehen oder eine Tasche hineinschneiden: Fläche anklicken, Heraus oder Hinein wählen, Rand zur Kante, Eckenradius und Tiefe einstellen und das Ergebnis als Vorschau sehen. Das geht auch bei importierten STL-Dateien, und was das Werkzeug anlegt, bleibt ein normaler Skizzenkörper, mit dem Körper gruppiert.
- **Um einen Zylinder wickeln** – ein SVG-Muster, ein Logo oder einen Schriftzug auf die Wand eines Bechers oder Rohrs legen, erhaben oder als Gravur, und mittig am Zylinder ausrichten.

### Dateien

- **Eigene Schriften** – jede TrueType-, OpenType- oder WOFF-Schrift für Text, in Chrome und Edge auch eine auf dem Computer installierte. Ein Entwurf behält nur die Umrisse der benutzten Buchstaben und öffnet sich deshalb überall. Arabisch und Hebräisch laufen von rechts nach links, arabische Buchstaben verbinden sich.
- **Eigene Modelle mitbringen** – STL, OBJ, 3MF, STEP, SVG oder DXF importieren und darum herum konstruieren. Eine DXF-Teilekontur, wie ein Laserschneid-Dienst oder ein Lieferant sie schickt, kommt als Körper mit ihren Löchern als eigenen Löchern, Bögen und Kreise bleiben echt. Ein SVG kommt als Skizzenkörper: als Fläche, als Kontur außen oder innen an seinen Linien, als Silhouette ohne Löcher oder rundum verbreitert - zusammen ein Ausstecher aus einer Datei oder die Schichten eines mehrfarbigen Logos. Die Textform hat dieselben Füllmodi, stellt die Buchstaben auf Wunsch senkrecht untereinander, zeichnet sie auf dem Kreisbogen schmaler oder breiter und wird zum Textblock aus mehreren Zeilen, links, mittig oder rechts ausgerichtet; die Formen-Bibliothek hat ein Namensschild: ein Text in farbigen Schichten für den Mehrfarbdruck, auf Wunsch mit Schlüsselringloch und gerundeter oder abgeschrägter Kante an den Buchstaben, und ein Symbolschild: ein SVG-Symbol in denselben farbigen Schichten, mit Anzahl und „so viele wie passen“, um eine Platte zu füllen. Eine farbige OBJ – aus layerling oder aus Tinkercad als ZIP mit ihrer `.mtl` – oder eine farbige 3MF, auch ein Slicer-Projekt, kommt als ein Körper je Farbe, eine 3MF mit mehreren Objekten als ein Körper je Objekt. Eine STEP-Datei mit mehreren Körpern kommt als ein Körper je Teil, mit seinem Namen und in seiner Farbe.
- **Netze exakt machen** – eine STL, OBJ oder 3MF von Printables oder Thingiverse besteht nur aus Dreiecken; „Exakt machen“ findet ihre Ebenen, Zylinder, Kegel, Kugeln und Tori und baut sie als exakten CAD-Körper neu, sodass eine Bohrung ein echter Zylinder ist: Rundungen und Fasen folgen sauberen Kanten, Flächen lassen sich löschen, und STEP trägt die echten Flächen. „Netz vereinfachen“ lässt scharfe Kanten und die Ränder von Bohrungen genau, wo sie sind, und dünnt ebene Flächen aus.
- **Exportieren, was dein Slicer will** – STL, 3MF mit Namen und Farben oder OBJ mit Farben, für die Auswahl oder die ganze Szene (Ausgeblendetes bleibt draußen), dazu STEP, wenn der Entwurf in ein vollwertiges CAD weiterreisen soll, und die Draufsicht als SVG oder als DXF mit echten Bögen und Kreisen für den Laserschneider, auf Wunsch mit Stegen wie bei einer Schablone, die die Mitte eines o oder b halten. PNG speichert ein sauberes Bild der Ansicht, in doppelter Auflösung und auf Wunsch mit durchsichtigem Hintergrund.
- **Zeichnung exportieren** – ein Teil auswählen oder die Auswahl für den ganzen sichtbaren Entwurf aufheben, dann **Exportieren → Zeichnung → PDF oder SVG** wählen. Erstellt Vorder-, Drauf- und rechte Seitenansicht in Erstwinkelprojektion auf einem gerahmten Zeichnungsblatt mit Zonennummern und Schriftfeld unten rechts, mit Gesamtmaßen, verdeckten Kanten und Tabellen für Durchmesser und Positionen achsparalleler runder Bohrungen. Maßstab 1:1 in Millimetern; das Blatt wächst mit dem Entwurf. Bei **100 % / tatsächlicher Größe** drucken. Bohrungspositionen beziehen sich auf die linke untere Ecke der Gesamtmaße jeder Ansicht. Schräge oder unrunde Bohrungen, Gewinde, Tiefen und Toleranzen werden nicht automatisch bemaßt. Die Projektion basiert auf der Zeichnungsarbeit aus [Cadverix-3D](https://github.com/WC3D/Cadverix-3D).
- **Hinweis auf Updates** – im veröffentlichten Programm bemerkt eine offene Seite eine neue Version selbst und bietet an, zu speichern und neu zu laden, samt Liste des Neuen.
- **Mehrere Entwürfe auf einmal löschen** – **Auswählen** auf der Startseite wählt Entwürfe per Klick auf ihre Karten (oder alle), und eine Frage löscht die ganze Auswahl; auch im Serverordner.
- **Ordner für Entwürfe** – die Entwürfe auf der Startseite in Ordner sortieren (auch Ordner in Ordnern), per Ziehen oder mit „Verschieben nach …“; die Suche schaut in alle, und „Alle sichern“ nimmt sie mit.
- **Projekte als Datei** – ein ganzes Projekt samt Verlauf, Skizzen und Gruppen als `.lyl` sichern und anderswo weiterbauen. In Chrome und Edge wählst du den Ordner selbst, und Strg+S speichert wieder in genau diese Datei; andere Browser laden sie herunter. Ältere `.skf`-Dateien aus früheren Fassungen öffnen sich weiterhin; gespeichert wird dann als `.lyl` daneben.
- **Fehlerbericht** – ein Link in der Fußzeile speichert ein ZIP mit dem Entwurf als `.lyl` und einem Text mit Version, Browser und den letzten Meldungen, fertig zum Anhängen im Forum oder bei GitHub, die eine bloße `.lyl` ablehnen.
- **Entwürfe, die du wiedererkennst** – jeder Entwurf mit Vorschaubild, in deinem Browser oder im Serverordner.
- **Anhänge** – Notizen, ein Foto des gedruckten Teils oder ein Datenblatt im Entwurf aufbewahren: `.md`- und `.txt`-Dateien, Bilder als `.png`, `.jpg` und `.webp` sowie PDF-Dateien reisen mit der `.lyl`-Datei. Das Auge öffnet einen Text oder ein Bild in einem Fenster; ein PDF wird heruntergeladen. SVG wird nicht angenommen, weil es Skripte tragen kann.

### Ansicht

- **Perspektivisch oder gerade von vorn** – zwischen normaler und orthografischer Ansicht wechseln, über den Würfelknopf neben den Zoomtasten oder mit **O**. Blickrichtung und Ausschnitt bleiben erhalten.
- **Ansicht am Würfel drehen** – Ziehen am Ansichtswürfel dreht die Ansicht wie die rechte Maustaste, auf dem Tablet mit einem Finger; ein Klick springt weiter auf die gerade Seite, ein Klick auf eine Ecke oder Kante schaut von dort. Die Tasten **1**–**6** springen ebenfalls, **Umschalt+1**–**6** zoomen dabei auf die Auswahl.
- **Vier gespeicherte Ansichten je Entwurf** – **Umschalt+7**, **8**, **9** oder **0** speichert die Ansicht genau so, wie sie ist (Blickwinkel, Ausschnitt, Zoom), und die Taste allein holt sie zurück. Jeder Entwurf hat seine eigenen, und eine gespeicherte `.lyl`-Datei nimmt sie mit.
- **Gerade auf die Arbeitsebene schauen** – **P** oder der Knopf neben „Arbeitsebene setzen“ in der Ansichtsleiste dreht die Ansicht gerade auf die Arbeitsebene, auch auf einer schrägen Fläche, mit ihrem Ursprung in der Mitte.
- **Der Ansichtswürfel in jeder Ecke** – Einstellungen > Darstellung > **Position des Ansichtswürfels** stellt den Würfel oben links, oben rechts, unten links oder unten rechts hin; in jeder Ecke außer oben links rückt die Ansichtsleiste an seinen Platz nach oben.
- **In deiner Sprache** – das Programm und seine Anleitung gibt es auf Englisch, Deutsch und in 17 weiteren Sprachen; die Sprachliste steht ganz oben rechts.
- **Von unten schauen** – das Auge über dem Gitter in der Ansichtsleiste blendet die Platte aus, damit die Unterseite eines Entwurfs frei zu sehen ist.
- **Eine zweite Ansicht im eigenen Fenster** – ein Knopf in der Ansichtsleiste öffnet ein zweites Fenster, das denselben Entwurf durch eine eigene Kamera zeigt, mit eigenem Ansichtswürfel und eigener Ansichtsleiste, und folgt jeder Änderung. Es öffnet sich dort, wo du es zuletzt gelassen hast.
- **Fenster nach Wunsch** – Objektliste, Einstellungen, Schnittansicht, Maßband und die Werkzeugfenster für Kanten, Aushöhlen und Muster lassen sich an ihrer Titelleiste frei verschieben und öffnen sich dort wieder; ein Doppelklick dockt sie an.
- **Rechtsklick-Menü** – ein kurzer Rechtsklick auf einen Körper bringt die häufigsten Befehle: duplizieren, Aussparung oder Körper, gruppieren, Fase, Rundung und Aushöhlen für einen Körper, spiegeln und um Prozent skalieren, ausblenden, sperren, Form sperren (lässt sich weiter verschieben, drehen und gruppieren, behält aber Größe und Einstellungen), auf die Arbeitsebene setzen, löschen. Ziehen mit der rechten Taste dreht weiter die Ansicht.
- **Andere ausblenden und Auswahl umkehren** – um an ein paar Teilen tief im Entwurf zu arbeiten, wählst du sie aus und blendest alles andere in einem Schritt aus (Rechtsklick-Menü oder Sichtbarkeitsmenü; Strg+Z oder Strg+Umschalt+H holt es zurück), oder du kehrst die Auswahl um, sodass jedes andere sichtbare Teil ausgewählt ist.
- **Schnittansicht** – die Ansicht entlang einer Ebene quer zu X, Y oder Z aufschneiden, um Wände, Hohlräume und ineinandergreifende Teile zu sehen, mit grobem und feinem Regler. Geschnitten wird nur die Ansicht: Entwurf und jeder Export bleiben ganz. Der Schnitt ist wie eine Zeichnung schraffiert, ein Körper in einem anderen andersherum; er lässt sich auch einfarbig füllen oder offen lassen. Den Schnitt selbst speichert „Schnitt als SVG“ im Maßstab 1:1, etwa für einen Laser oder eine Schablone, „Messen“ liest Wandstärken und Spalte direkt auf dem Schnitt ab, im rechten Winkel zur Wand eingerastet, und „Skizze aus Schnitt“ beginnt eine Skizze direkt auf dem Schnitt mit seinen Umrissen darin (Löcher als echte Kreise), für einen Deckel, einen Einsatz oder eine Dichtung, die passt.
- **Arbeitsebene auf jeder Fläche** – W drücken und eine Fläche anklicken, um darauf zu bauen; ein Klick nahe einer Ecke setzt sie genau auf die Ecke, nahe einer Kante auf die Kante mit dem Raster an ihr entlang, und auf der freien Platte dorthin, wo du klickst. Ein Auge blendet die Ebene für freie Sicht aus, sie gilt trotzdem weiter. Auch eine KI kann sie auf eine Fläche legen.
- **Maustasten wie im Slicer, und eine 3D-Maus** – in den Einstellungen lassen sich die Maustasten wie in Bambu Studio und OrcaSlicer belegen: Ziehen mit links auf leerer Fläche dreht die Ansicht, die rechte Taste verschiebt sie, und Umschalt mit Ziehen links spannt den Auswahlrahmen. Eine SpaceMouse oder eine andere 3D-Maus dreht, verschiebt und zoomt die Ansicht in Chrome und Edge, sobald sie dort einmal verbunden ist.
- **Auf einem Tablet** – ein Finger arbeitet am Entwurf, genau wie die linke Maustaste: Antippen wählt aus, Ziehen verschiebt, Ziehen auf leerer Fläche spannt den Auswahlrahmen. **Zwei Finger gehören der Ansicht**: Spreizen und Zusammenziehen zoomt, gemeinsames Schieben verschiebt die Arbeitsfläche. Setzt der zweite Finger auf, wird zurückgenommen, was der erste angefangen hatte; ein Zoom verschiebt also nie versehentlich ein Teil. Fürs Drehen gibt es keine eigene Geste, dafür einen Umschalter in der Ansichtsleiste, der nur auf einem Berührungsbildschirm erscheint: Solange er an ist, dreht ein Finger die Ansicht, statt auszuwählen. Zahlenfelder geben beim Antippen ihren ganzen Wert zum Überschreiben frei – eine Dezimaltastatur hat keine Pfeiltasten, mit denen sich der Schreibzeiger setzen ließe. Ein Finger greift zu Skizzenpunkten, Linien, Griffen, Messpunkten und Kanten etwas weiter als eine Maus, aber **auf einem Tablet ist ein Stift das bessere Werkzeug**: feiner, und er verdeckt nicht, was du treffen willst.

### Videos

Von anderen gemacht, nicht von diesem Projekt:

<!-- videos:start -->
- [Layerling Tutorials](https://www.youtube.com/playlist?list=PLZ-ZWS0D1JIk) – HL ModTech (Englisch). Eine Playlist von einem Tinkercad-Nutzer, bisher mit einem Blick auf layerling von etwa 23 Minuten (kostenloses CAD im Browser, das Tinkercad erweitert), einem tieferen Einstieg in die Funktionen und einem kurzen Update zu gedruckten Gewinden.
- [Layerling – Playlist](https://www.youtube.com/playlist?list=PLCsBmX2kOGWs) – Making Layers (Englisch). Eine Reihe zu layerling, bisher mit „Tinkercad alternative / upgrade? Introducing Layerling!“, einem Überblick für Tinkercad-Umsteiger, und „Layerling Sketch Tools!“ zu den Skizzenwerkzeugen.
- [Layerling](https://www.youtube.com/playlist?list=PLYqVFeqYBrPE) – TECHNOBENTO (Englisch). Eine Playlist über layerling, bisher mit „A new way to sketch in Layerling“.
- [Layerling CAD Videos](https://www.youtube.com/playlist?list=PLc09BHr_6nn8) – Printology (Englisch). Eine Playlist über layerling, bisher mit „I'm 100% In on Layerling - The Next Big Free CAD“ und „Layerling Features That Blow Tinkercad Out Of The Water“.
- [I Tried Layerling After Tinkercad… Is It REALLY Better?](https://youtu.be/5DpOxdoNwqs) – Maker Mates Studio 3D Printing (Englisch). Jemand, der von Tinkercad kommt, probiert layerling aus und vergleicht die beiden.
- [Print by Layer](https://www.youtube.com/playlist?list=PLejZBz4L7CGQ) – Print N Repeat (Englisch). Eine Playlist über layerling, bisher mit „The EASIEST Way to Design Hinges in Layerling“ und „The EASIEST Way to 3D Model Threads!“.
- [Tinkercad Too Basic? Fusion 360 Too Much? Meet Layerling for 3D Printing](https://youtu.be/kzV7fQ3rXhw) – 3D Jesus | 3D Printing & Design (Englisch). Ein erster Test von layerling ganz ohne Anleitung: Verrunden und Fasen, Aushöhlen, Gewinde, Skizzen, Drehkörper, Muster, Import und Druckerprofile.
- [Layerling en español | Del primer contacto al proyecto completo](https://www.youtube.com/playlist?list=PLVWA8wsStnyw) – Random Maker (Spanisch). Eine Playlist auf Spanisch, vom ersten Blick auf layerling bis zu kompletten Projekten: worin es sich von Tinkercad unterscheidet, ein Vergleich Punkt für Punkt und wie man Projekte hinüberbringt.
- [Proyectos en Layerling](https://www.youtube.com/playlist?list=PLTEdmvVC2bxs) – Fulcro 1900 (Spanisch). Eine Playlist mit Projekten in layerling, bisher mit einer Vorstellung von layerling als kostenlosem Werkzeug, das vollständiger ist als Tinkercad, Schreibtischzubehör (drei Modelle), einer Handyhülle sowie Gewindestange, Mutter und Schraube.
- [Layerling](https://www.youtube.com/playlist?list=PLQuXPoMXTnRQ) – Werkplaats Marc (Niederländisch). Eine Playlist über layerling, bisher mit einem ersten Blick für Tinkercad-Umsteiger („Layerling - De Gratis Tussenstap van Tinkercad naar Fusion 360“) und einer Anleitung zu Skizzen: Foto nachzeichnen, Drehen und entlang eines Pfads ziehen („Schetsen Uitgelegd“).
<!-- videos:end -->

## Loslegen

Am schnellsten geht es mit der gehosteten Fassung. Nichts zu installieren, nichts anzumelden – öffnen und bauen:

**https://layerling.com/**

Der Rest dieses Abschnitts handelt davon, eine eigene Instanz zu betreiben: auf deinem Rechner oder auf einem Rechner in
der Werkstatt, den alle im Browser öffnen. Woher die App auch ausgeliefert wird: Nichts geht an Dritte. Die Entwürfe bleiben
im Browser, in dem sie entstanden sind (oder im Serverordner, den du selbst einrichtest), und Exporte landen direkt auf dem Rechner der jeweiligen Person.

### Schnellstart unter Windows

Noch nie ein Terminal benutzt? Auf einem Windows-11-Rechner (oder aktuellem Windows 10) ohne Vorinstallationen
**PowerShell** öffnen (im Startmenü danach suchen, keine Administratorrechte nötig) und diese eine Zeile einfügen:

```powershell
irm https://raw.githubusercontent.com/henmedia/layerling/main/scripts/windows-quickstart.ps1 | iex
```

Das installiert Git und Node.js, falls sie fehlen, lädt layerling nach `%USERPROFILE%\layerling` herunter und öffnet es
im Browser unter `http://127.0.0.1:3000/`. Lass das PowerShell-Fenster offen, solange du layerling benutzt; `Strg+C` in
diesem Fenster beendet es wieder.

Dieselbe Zeile später noch einmal ausführen **aktualisiert** layerling – das Skript erkennt den vorhandenen Ordner und
holt die neueste Fassung, statt sie erneut komplett herunterzuladen. Das Skript selbst liegt unter
[`scripts/windows-quickstart.ps1`](scripts/windows-quickstart.ps1); du kannst also genau nachlesen, was es tut, bevor
du es ausführst, oder es herunterladen und lokal starten, statt es in PowerShell hineinzuleiten.

#### Später wieder öffnen

Die Zeile von oben legt außerdem eine Verknüpfung namens **„Start layerling“** auf deinem Desktop an. Einfach
doppelklicken, um layerling erneut zu öffnen – kein PowerShell, keine Neuinstallation, kein erneuter Download: Der
Server startet von selbst, und der Browser öffnet sich gleich mit. Außerdem **aktualisiert** die Verknüpfung layerling zuerst (sofern der Ordner keine eigenen
Änderungen enthält) und öffnet den Browser erst, wenn der Server wirklich bereit ist. Läuft layerling schon, startet sie keinen zweiten Server
und aktualisiert nicht unter dem laufenden, sondern öffnet nur die Seite. Soll layerling woanders liegen, etwa auf
einem anderen Laufwerk? Dann das Skript mit dem gewünschten Ordner starten:

```powershell
& ([scriptblock]::Create((irm https://raw.githubusercontent.com/henmedia/layerling/main/scripts/windows-quickstart.ps1))) -InstallPath "D:\3DPrinter\Layerling"
```

Stammt deine Verknüpfung aus einer älteren Fassung des Skripts, die Zeile einmal erneut ausführen; sie ersetzt die Verknüpfung durch die neue.

Lieber von Hand? PowerShell öffnen und Folgendes eingeben:

```powershell
cd $env:USERPROFILE\layerling
npm run dev
```

Dann selbst `http://127.0.0.1:3000/` öffnen. `Strg+C` in diesem Fenster beendet layerling so oder so wieder.

### Schnellstart auf dem Mac

Öffne auf dem Mac die App **Terminal** (Cmd+Leertaste drücken, `Terminal` tippen, Enter drücken) und füge diese eine Zeile ein:

```bash
curl -fsSL https://raw.githubusercontent.com/henmedia/layerling/main/scripts/mac-quickstart.sh | sh
```

Dafür brauchst du Git und Node.js 22.18 oder neuer. Fehlt eines, sagt das Skript, was du installieren sollst (macOS bietet die Entwicklerwerkzeuge mit Git in einem Fenster an, Node.js gibt es als Installer auf [nodejs.org](https://nodejs.org); mit Homebrew installiert es beides selbst), und hält an, damit du dieselbe Zeile noch einmal ausführen kannst. Danach lädt es layerling nach `~/layerling` herunter, legt **„Start layerling“** auf den Schreibtisch und öffnet layerling im Browser unter `http://127.0.0.1:3000/`. Lass das Terminal-Fenster offen, solange du layerling benutzt; `Ctrl+C` in diesem Fenster beendet es wieder.

Dieselbe Zeile später noch einmal ausführen **aktualisiert**: Der vorhandene Ordner bleibt, und beim Start holt layerling zuerst die neueste Fassung. Das Skript liegt unter [`scripts/mac-quickstart.sh`](scripts/mac-quickstart.sh); du kannst also nachlesen, was es tut, bevor du es ausführst. Für einen anderen Ordner: `LAYERLING_DIR=~/3D/layerling sh mac-quickstart.sh` (nach dem Herunterladen des Skripts). Auf einem echten Mac ist es noch nicht ausprobiert; wenn etwas schiefgeht, sag es bitte in den Diskussionen.

### Docker

Um layerling auf einem Rechner, NAS (Synology, Unraid usw.) oder Heimserver ohne Node.js zu betreiben, nimmst du das fertige Image **`henmedia/layerling`** auf Docker Hub (auch unter **`ghcr.io/henmedia/layerling`**, dasselbe Image). Jedes Release veröffentlicht es für amd64 und arm64 (Raspberry Pi, ARM-NAS), unter seiner Versionsnummer und als `latest`. Die App lauscht auf Port **3000**.

Am schnellsten geht es mit einem einzigen Befehl:

```bash
docker run -d --name layerling -p 3000:3000 -v layerling-thumbnails:/app/.codex/project-thumbnails --restart unless-stopped ghcr.io/henmedia/layerling:latest
```

Die Option `-v` legt die Vorschaubilder der Startseite in ein Docker-Volume namens `layerling-thumbnails`, damit sie ein Update überstehen; ohne sie liegen sie im Container und sind bei jedem Neuanlegen weg (die Entwürfe selbst sind davon nicht berührt: Sie liegen im Browser oder im Serverordner). Auf einem NAS mit Container-Verwaltung (Synology Container Manager, Unraid, Portainer) suchst du in der Registrierung (Docker Hub) nach `henmedia/layerling` oder trägst `henmedia/layerling:latest` ein, gibst Port 3000 frei und legst ein Volume für `/app/.codex/project-thumbnails` an. Zum Aktualisieren das Image neu holen und den Container neu anlegen (oder Watchtower das erledigen lassen). Unter **Unraid** steht layerling auch im App-Store (Community Applications): nach „Layerling“ suchen und mit wenigen Klicks installieren; die Vorlage von [jbat66](https://github.com/jbat66/unraid-templates) richtet die Serverspeicherung auf einer Unraid-Freigabe gleich mit ein.

Die Image-Tags sind reine Versionsnummern **ohne „v“**: `ghcr.io/henmedia/layerling:1.42.0`, das GitHub-Release heißt dagegen `v1.42.0`. Ein Pull holt nur das neue Image; ein vorhandener Container läuft mit dem alten weiter, bis er entfernt und neu angelegt wird:

```bash
docker pull ghcr.io/henmedia/layerling:latest
docker stop layerling
docker rm layerling
docker run -d --name layerling -p 3000:3000 -v layerling-thumbnails:/app/.codex/project-thumbnails --restart unless-stopped ghcr.io/henmedia/layerling:latest
```

Mit `docker inspect layerling | grep image.version` siehst du, welche Version der Container wirklich ausführt. Hast du für den Serverspeicher einen Ordner eingebunden, gib dieselbe `-v`-Option wieder mit an.

Willst du das Image lieber selbst bauen, nimm das mitgelieferte [`Dockerfile`](docker/Dockerfile) und [`compose.yml`](docker/compose.yml):

1. **Docker installieren.** Unter Windows oder macOS [Docker Desktop](https://www.docker.com/products/docker-desktop/) installieren und starten. Unter Linux oder auf einem NAS brauchst du Docker mit Compose (`docker compose` oder das eigenständige `docker-compose`).
2. **Dateien holen.** Entweder das Repository als ZIP herunterladen ([Code → Download ZIP](https://github.com/henmedia/layerling/archive/refs/heads/main.zip)) und entpacken oder per Git klonen:
   ```bash
   git clone https://github.com/henmedia/layerling.git
   cd layerling
   ```
3. **Starten.** Im Projektordner ein Terminal öffnen (z. B. PowerShell unter Windows) und ausführen:
   ```bash
   docker compose -f docker/compose.yml up -d --build
   ```
   Mit dem älteren eigenständigen Programm heißt es `docker-compose` statt `docker compose`. Docker baut das Image und startet den Container im Hintergrund (`-d`); beim ersten Mal dauert der Build etwa 2–3 Minuten. Ohne `--build` holt derselbe Befehl stattdessen das fertige Image.
4. **Öffnen.** Auf demselben Rechner unter **`http://localhost:3000/`**, von anderen Geräten im Netz unter **`http://<IP-DEINES-SERVERS>:3000/`**.

Befehle im Alltag:

- **Stoppen:** `docker compose -f docker/compose.yml down`
- **Wieder starten:** `docker compose -f docker/compose.yml up -d`
- **Aktualisieren** (nach `git pull` oder neuem ZIP): `docker compose -f docker/compose.yml up -d --build`; mit dem fertigen Image `docker compose -f docker/compose.yml pull` und danach `up -d`

Das Image führt `next start` im Produktionsmodus aus, die MCP-Brücke ist dort also aus, solange du sie nicht einschaltest (siehe [Eine KI an eine Kopie auf NAS oder Server lassen](#eine-ki-an-eine-kopie-auf-nas-oder-server-lassen)). Für einen
gemeinsamen Projektordner ein beschreibbares Verzeichnis einbinden und in `compose.yml` `LAYERLING_SHARED_PROJECTS_DIR`
auf den Pfad im Container setzen, an dem es eingebunden ist, etwa `./shared-projects:/shared-projects` mit
`LAYERLING_SHARED_PROJECTS_DIR: "/shared-projects"` (siehe [Gemeinsame Entwürfe im Netz](#gemeinsame-entwürfe-im-netz)).
Der Container läuft als der Benutzer mit der Nummer 999, und dieser muss in den Ordner schreiben dürfen: `sudo chown 999:999 ./shared-projects`, oder dem Dienst `user: "1000:1000"` hinzufügen (deine eigenen Benutzer- und Gruppennummern, `id -u` und `id -g` zeigen sie), dann läuft der Container als du. Ohne das erscheint der Ordner auf der Startseite, aber es lässt sich nichts darin speichern. Nach einer Änderung `docker compose up -d` ausführen: `docker compose restart` behält die alte Einstellung.
`docker exec <Container> printenv LAYERLING_SHARED_PROJECTS_DIR` zeigt die tatsächlich verwendete.

Damit jeder Entwurf in diesem Ordner liegt und keiner im Browser, gibt es eine vollständige Anleitung auf Englisch und Deutsch mit eigener Compose-Datei und einem Update-Skript, das die Einstellungen prüft, den Ordner sichert und ein fehlgeschlagenes Update zurückrollt: [docs/docker](docs/docker/README.md), geschrieben von Jürgen Keller. Mit `LAYERLING_NEW_DESIGNS_ON_SERVER: "always"` landet alles, was einen Entwurf anlegt, im Serverordner: die Kachel, das Öffnen oder Importieren einer Datei, das Wiederherstellen einer Sicherung (mit ihren Ordnern), das Duplizieren und ein Stand aus dem Verlauf; Neuer Ordner auf der Startseite legt einen Serverordner an.

Das Farbschema, das Leute beim ersten Besuch bekommen, legst du mit `LAYERLING_DEFAULT_THEME` fest: `system`, `light`, `dark` oder `graphite` (auf demselben Weg, in `compose.yml` oder in der Umgebung von `npm run start`). Wer layerling schon geöffnet hat, behält das Schema, das sein Browser bereits hat, und jeder kann es weiter mit dem Umschalter ändern. Ohne die Einstellung folgt das Schema dem System. Eine Kopie, die als reine Dateien ausgeliefert wird, hat keinen Server, der sie lesen könnte, dort gilt sie nicht.

Ist der gemeinsame Ordner eingerichtet, lässt `LAYERLING_NEW_DESIGNS_ON_SERVER` neue Entwürfe auf dem Server beginnen: `true` ist der Anfangswert für alle, die noch nicht gewählt haben (sie können **Neue Entwürfe auf dem Server** auf der Startseite abwählen), `always` gilt für alle und sperrt den Haken. Es wird auf demselben Weg gesetzt, und eine als reine Dateien ausgelieferte Kopie hat keinen Server, der es lesen könnte.

Hinter einem Reverse-Proxy mit Domain muss der Proxy den ursprünglichen `Host` und `X-Forwarded-Proto` weitergeben (nginx: `proxy_set_header Host $host;` und `proxy_set_header X-Forwarded-Proto $scheme;`), sonst lehnt der Server das Speichern mit "Der Serverspeicher nimmt nur Anfragen von dieser Seite an." ab. Schreibt der Proxy den Host um und lässt sich das nicht ändern, trägst du die Adresse, unter der die Leute layerling öffnen, in `LAYERLING_ALLOWED_ORIGINS` ein (kommagetrennt, zum Beispiel `https://layerling.example.com`).

### Statisches Hosting: reine Dateien auf einem Webserver

Jeder Webserver kann layerling als reine Dateien ausliefern; auf ihm läuft kein Node.js. Du baust die Dateien einmal auf einem Rechner mit Node.js (siehe [Was du brauchst](#was-du-brauchst)):

```bash
npm install
npm run export
```

Die fertige Seite liegt in **`apps/web/.next-export/`**. Kopiere den **Inhalt** dieses Ordners (nicht den Ordner selbst) in das Dokumentenverzeichnis des Webservers, sodass `index.html` direkt darin liegt.

Vier Dinge zu wissen:

- **layerling braucht eine eigene Adresse.** Die Dateien verweisen mit Pfaden aufeinander, die an der Wurzel beginnen (`/_next/...`). layerling muss deshalb an der Wurzel einer Adresse ausgeliefert werden, etwa `https://layerling.example.com/` oder `http://192.168.0.5:8080/`. In einem Unterordner (`https://example.com/layerling/`) läuft es nicht, und von der Festplatte (`file://`) lässt es sich nicht öffnen. Siehst du nur einen Block Text ohne jede Gestaltung, wurden die Skript- und Stildateien nicht geladen: Öffne die Entwicklerwerkzeuge des Browsers (F12), sieh im Reiter „Netzwerk“ nach roten Einträgen `/_next/...` und vergleiche deren Adresse mit dem Ort, an den du die Dateien gelegt hast.
- **Ordner, die mit einem Unterstrich beginnen, müssen ausgeliefert werden.** Manche Server verstecken sie (GitHub Pages zum Beispiel ohne eine Datei `.nojekyll`), und in `_next` steckt das ganze Programm.
- **Ein schneller Test auf dem eigenen Rechner:** `npx serve apps/web/.next-export` und die angezeigte Adresse öffnen.
- **Als App installieren und offline nutzen geht nur mit https.** Der Export enthält die Offline-Dateien (`sw.js`), aber ein Browser nutzt sie nur unter einer `https://`-Adresse oder auf `localhost`, nicht unter einer einfachen `http://`-Adresse im eigenen Netz.

### Gemeinsame Entwürfe im Netz

layerling selbst besteht nur aus Dateien, der gemeinsame Ordner braucht also etwas auf dem Server, das schreiben kann. Es gibt zwei Wege, und du brauchst nur einen: **Node oder Docker** (dieser Abschnitt, mit `LAYERLING_SHARED_PROJECTS_DIR`) oder **ein gewöhnlicher Webserver mit PHP** (der Ordner `store`, weiter unten). Ein Webserver, der die Dateien nur ausliefert – `npx serve`, nginx oder Apache ohne PHP –, zeigt layerling ganz normal, hat aber keinen Serverordner.

Betreibst du layerling mit `npm run dev` oder `npm run start` auf einem Rechner, den andere im Browser öffnen, kann es
einen gemeinsamen Ordner für `.lyl`-Projekte anbieten. `npm run start` liefert aus, was `npm run build` gebaut hat, führe das also
einmal vorher aus. Setze vor dem Start `LAYERLING_SHARED_PROJECTS_DIR` auf ein Verzeichnis, in das der Benutzer schreiben darf, der
layerling startet (ein Ordner unter `/srv` gehört oft root, lege einen eigenen an oder ändere den Besitzer):

```bash
LAYERLING_SHARED_PROJECTS_DIR=/srv/layerling-projekte npm run start
```

Auf der Startseite steht dann neben deinen Browser-Entwürfen der Ordner **Auf dem Server**. Öffnest du ihn, bist du in
diesem Ordner: **Neuer Entwurf** legt einen darin an, **Neuer Ordner** einen Unterordner, und die Pfadzeile unter der
Überschrift sagt, wo du bist. Eine `..`-Kachel führt wieder hinaus, und **Zurück zu den Entwürfen in diesem Browser** links neben den Knöpfen bringt dich zu den Entwürfen dieses Browsers zurück. Entwürfe wandern per Ziehen auf einen Ordner, auf
diese Kachel oder auf einen Schritt der Pfadzeile – oder über **Verschieben nach …** in ihrem Menü. Ein Entwurf aus dem
Browser kommt genauso auf den Server: seine Kachel auf den Serverordner ziehen.

Zwei Schaltflächen auf der Startseite ersparen das Verschieben von Hand: **Alle auf den Server legen** legt alle Entwürfe dieses Browsers auf einmal in den Serverordner, und der Haken **Neue Entwürfe auf dem Server** lässt jeden neuen Entwurf gleich im Serverordner beginnen, sodass er sich dort ab der ersten Änderung sichert. Ein Entwurf, dessen Name auf dem Server schon vergeben ist, bleibt im Browser.

Das Suchfeld oben durchsucht den **ganzen** Serverordner, nicht nur den, in dem du gerade stehst. Jeder Treffer sagt,
in welchem Ordner er liegt, und dieser Ordner ist ein Knopf: ein Klick, und du bist dort, die Suche ist beendet.
Ordner werden ebenfalls über ihren Namen gefunden. Solange du suchst, sagt die Serverkachel auf der Startseite, wie
viele Treffer dort drüben liegen.

**Duplizieren** im Menü eines Entwurfs legt eine Kopie an. Auf dem Server wird die Datei selbst kopiert, neben dem
Original und unter einem freien Namen, das Vorschaubild inbegriffen – es wird nichts neu gepackt, die Kopie trägt also
genau die Geometrie des Originals. Im Browser entsteht ein eigener Entwurf mit denselben Formen, demselben Verlauf und
einem eigenen Vorschaubild, und er gehört niemandem auf dem Server.

Ein Entwurf, der auf dem Server liegt, sichert sich von selbst dorthin zurück – fünf Sekunden nach der letzten Änderung
und beim Verlassen des Editors. Vorschaubilder landen daneben in `.thumbnails`. Was nur im Browser liegt, bleibt dort
unberührt.

Eigene Formen, die auf dem Server abgelegt werden, kommen in einen Ordner `Custom shapes` oben im Speicher, je eine
`.lyl` mit Vorschaubild. layerling legt ihn mit der ersten solchen Form an. Er ist ein ganz normaler Ordner, erscheint also
auf der Startseite, und eine Form darin lässt sich wie ein Entwurf öffnen und speichern. Weder die Node-Route noch
`store.php` brauchen dafür etwas Zusätzliches.

Was du in den Arbeitsbereich-Einstellungen mit „Als Vorgabe sichern“ festlegst, liegt ebenfalls im Speicher, als
`.settings/default.json` (ein versteckter Ordner, den die Startseite nicht zeigt). Ein Browser, der seine eigene Vorgabe
verloren hat, weil sein Speicher geleert wurde oder weil es ein anderer Browser ist, holt sie sich beim Laden der Startseite,
und neue Entwürfe beginnen wieder damit. Es gibt eine Vorgabe für den ganzen Speicher; die zuletzt gesicherte gilt, egal aus
welchem Browser. Wer die Datei löscht, hat wieder die Vorgabe des jeweiligen Browsers.

Wer eine gemeinsame Datei öffnet, erhält eine private lokale Arbeitskopie. Beim Zurückspeichern wird zuerst der Stand auf
dem Server geprüft; hat jemand anderes die Datei inzwischen geändert, verweigert layerling das Überschreiben und bittet
darum, neu zu laden oder unter anderem Namen zu speichern. Das ist gemeinsame Dateiablage, kein gleichzeitiges Bearbeiten.

Hinter einem Reverse Proxy mit Anmeldung (etwa Authelia, oauth2-proxy, Cloudflare Access oder HTTP Basic Auth) bekommt
jeder Benutzer einen eigenen Ordner `.users/<Benutzer>/`, wenn du `LAYERLING_USER_HEADER` auf den Header setzt, den dein
Proxy mitschickt (z. B. `LAYERLING_USER_HEADER=X-Forwarded-Email`, in Apache `SetEnv LAYERLING_USER_HEADER Remote-User`).
Das ist nur sicher, wenn layerling ausschließlich über den Proxy erreichbar ist, damit niemand den Header direkt an den
Server schicken kann. Ohne die Einstellung bleibt alles wie bisher.

#### Ohne Node: der Ordner `store`

Wird layerling als statischer Export ausgeliefert – also als reine Dateien auf einem Webserver –, kann es von sich aus
nichts schreiben. Für diesen Fall reist `store.php` mit dem Export. Lege neben `index.html` einen Ordner `store` an, den
der Webserver beschreiben darf, und layerling bietet dieselbe gemeinsame Ablage an wie oben, samt Ordnern. Fehlt der
Ordner, bleibt die Funktion unsichtbar, und die Kurzanleitung im Editor sagt, wie man sie einschaltet. Der Webserver muss
PHP können.

Der Ordner hat **keine Anmeldung**: Wer die Seite erreicht, kann darin lesen, schreiben und löschen. Im Heimnetz oder in
der Werkstatt ist genau das der Zweck; auf einer öffentlich erreichbaren Seite schütze ihn oder lege ihn nicht an.

Nichts im Ordner soll über seine Adresse geöffnet werden: layerling liest und schreibt ihn nur über `store.php`. Unter
Apache legt `store.php` dort eine `.htaccess` an, die jeden direkten Abruf abweist. Apache liest sie nur, wo
`AllowOverride` es erlaubt (Debian stellt `/var/www` auf `None` und übergeht sie), nginx und andere Server nie; sperre
`store/` dort selbst (in Apache: `<Directory /var/www/html/store> Require all denied </Directory>`, in nginx:
`location /store/ { deny all; }`). `store.php` prüft außerdem jeden Export, den es speichert, und weist eine Datei ab,
die in einem Browser etwas ausführen könnte.

Der Ordner kann auch außerhalb des Web-Roots liegen, wo ihn keine Adresse erreicht, ob mit `.htaccess` oder ohne:
Setze `LAYERLING_SHARED_PROJECTS_DIR`, dieselbe Einstellung, die der Node-Server liest, auf seinen Pfad – in Apache
mit `SetEnv LAYERLING_SHARED_PROJECTS_DIR /var/layerling-projects`, in nginx mit
`fastcgi_param LAYERLING_SHARED_PROJECTS_DIR /var/layerling-projects;`, in Docker als Umgebungsvariable des
Containers. Dieser Ordner tritt dann an die Stelle von `store`; auch er muss vorhanden sein und für den Webserver
beschreibbar.

Beim Ausliefern daran denken: Wer den Export mit einer Option spiegelt, die Überzähliges löscht – `rsync --delete`,
`robocopy /MIR`, WinSCP `-delete` –, muss `store` ausdrücklich ausnehmen. Sonst räumt jedes Update die Projekte weg.

## An layerling arbeiten

Diesen Weg nimmst du, wenn du den Quelltext ändern willst.

### Was du brauchst

- Node.js 22.18 oder neuer (die Skripte für Anleitung und Schriften laden TypeScript-Dateien direkt, das können ältere Versionen nicht); 24 geht auch, das Docker-Image nutzt es
- npm, in Node.js enthalten

Die Versionen prüfst du mit `node -v` und `npm -v`. Funktionieren die Befehle nicht, installiere Node.js von der
offiziellen Node.js-Seite und öffne das Terminal neu.

### Installieren und starten

```bash
git clone https://github.com/henmedia/layerling.git
cd layerling
npm install
npm run dev
```

Kein Git? Auf der GitHub-Seite den grünen Knopf **Code** drücken, **Download ZIP** wählen, entpacken, im entpackten
Ordner ein Terminal öffnen und mit `npm install` beginnen.

Dann `http://127.0.0.1:3000/` öffnen. Lass das Terminal offen, solange du die App benutzt; `Strg+C` beendet den
Entwicklungsserver.

Unter Linux und macOS erledigt `scripts/start-layerling.sh` den täglichen Start: Es aktualisiert zuerst den Ordner (übersprungen, wenn du darin Dateien geändert hast), startet den Server, wartet, bis er antwortet, und öffnet dann den Browser. Aufrufen kannst du es von überall, etwa `~/layerling/scripts/start-layerling.sh`. Es braucht Git und Node.js wie oben. Läuft layerling auf dem Port schon, öffnet es nur den Browser, statt einen zweiten Server zu starten. Hält ein anderes Programm Port 3000, starte es mit `PORT=3100 scripts/start-layerling.sh`. Ausprobiert ist es unter Debian Linux (ohne Desktop, der Browserschritt gibt dort nur die Adresse aus) und in einer Windows-Shell; macOS ist ungetestet – wenn es bei dir hakt, sag es bitte in den Diskussionen.

### Entwickeln in einem Container

Du möchtest Node.js lieber nicht installieren? Entwickle stattdessen in einem Container. Du brauchst eine
Container-Engine mit Compose – `docker compose` oder `podman compose` (auch rootless Podman unter SELinux funktioniert;
das `:z` in der Compose-Datei übernimmt die Dateimarkierungen):

```bash
docker compose -f docker/compose.dev.yml up
```

Öffne `http://127.0.0.1:3000/`. Der erste Start installiert die Abhängigkeiten; bei späteren Starts geht es direkt in
den Entwicklungsserver mit Hot Reload. Zum Beenden `Strg+C` drücken. Wenn du Abhängigkeiten aktualisierst und etwas
veraltet wirkt, lösche `node_modules/` im Projektordner und starte neu.

Betreibst du gleichzeitig den Produktionscontainer aus `docker/compose.yml`? Der benutzt ebenfalls Port 3000 – ändere
den Host-Port bei einem der beiden (z. B. `"3100:3000"`).

### Nützliche Befehle

| Befehl | Was er tut |
| --- | --- |
| `npm run typecheck` | TypeScript prüfen |
| `npm run test` | Unit-Tests |
| `npm run test:e2e` | End-to-End-Tests |
| `npm run guide` | Die Seiten der Anleitung aus `docs/guide` bauen (Export und `npm run dev` tun das auch) |
| `npm run guide:images` | Die Bilder der Anleitung neu aus dem laufenden Programm aufnehmen (braucht `npm run dev -- -p 3010`; siehe `docs/guide/README.md`) |
| `npm run build` | Produktions-Build (`npm run start` liefert ihn aus) |
| `npm run export` | Statischer Export für einfaches Webhosting |
| `npm run printers:update` | Druckervorlagen aus den OrcaSlicer-Profilen auffrischen |
| `npm run mcp:layerling` | MCP-Server für KI-Clients starten (siehe unten) |

## layerling-MCP-Skill

layerling bringt einen lokalen MCP-Server für KI-Clients mit, die MCP-Werkzeuge unterstützen. Ein Agent kann damit einen
laufenden Editor-Tab untersuchen und steuern: offene Editoren auflisten, die Szene lesen, Objekte anlegen, ändern und
auswählen, Teile gruppieren, schneiden und trennen, CAD-Kanten-IDs auflisten, Kanten fasen oder verrunden, Körper
aushöhlen, Fehler einsehen und Bilder der Ansicht aufnehmen.

Das funktioniert mit einem lokalen Entwicklungsserver. In Produktions-Builds und beim statischen Hosting ist die
MCP-Route abgeschaltet, es sei denn, der Server schaltet sie mit einem Zugriffsschlüssel ein
([siehe unten](#eine-ki-an-eine-kopie-auf-nas-oder-server-lassen)); auf layerling.com ist sie immer aus.

1. layerling im Projektordner mit `npm run dev` starten (siehe [Installieren und starten](#installieren-und-starten)).
2. Einen Editor-Tab öffnen, z. B. `http://127.0.0.1:3000/?editor=1` - oder weglassen: Ist keiner offen, startet das erste Werkzeug, das einen braucht, deinen Browser mit einem Editor (nicht bei einer Kopie auf NAS oder Server; mit `LAYERLING_MCP_OPEN_EDITOR=0` abgeschaltet).
3. Den KI-Client wie unten beschrieben anbinden. Er startet den MCP-Server selbst mit
   `node scripts/layerling-mcp-server.mjs`.

Die wichtigsten Werkzeugnamen sind `layerling_list_editors`, `layerling_read_scene`, `layerling_list_objects`,
`layerling_create_shape`, `layerling_update_object`, `layerling_list_edges`, `layerling_apply_edge_treatment`,
`layerling_hollow_object`, `layerling_offset_object`, `layerling_cut_out`, `layerling_punch`, `layerling_make_lid`, `layerling_array_objects`, `layerling_set_section_view` und `layerling_capture_image`.

### Claude Code

Nichts zu installieren: Das Repo bringt bereits `.mcp.json` mit, das den MCP-Server für dieses Projekt einträgt, sowie eine
Kopie des Skills unter `.claude/skills/layerling-mcp-skill` – genau dort sucht Claude Code danach. Öffne den
layerling-Ordner in Claude Code und bitte:

```text
Use the layerling MCP tools to list my open layerling editors and inspect the current scene.
```

### Claude Desktop

Claude Desktop liest weder die `.mcp.json` eines Projekts noch Skill-Dateien, kann aber denselben MCP-Server über seine
eigene Konfiguration nutzen. Trage den Server dort ein; als Vorlage dient
[`docs/mcp/claude-desktop-config.example.json`](docs/mcp/claude-desktop-config.example.json), wobei du den Skriptpfad durch
den absoluten Pfad auf deinem Rechner ersetzt. Nach einem Neustart von Claude Desktop:

```text
Use the layerling MCP tools to list open editors, inspect the scene, and modify the selected object.
```

### Codex

Kopiere den Skill aus `docs/skills/layerling-mcp-skill` in deinen Codex-Skill-Ordner.

Windows PowerShell:

```powershell
New-Item -ItemType Directory -Force "$env:USERPROFILE\.codex\skills" | Out-Null
Copy-Item -Recurse -Force "docs\skills\layerling-mcp-skill" "$env:USERPROFILE\.codex\skills\layerling-mcp-skill"
```

macOS oder Linux:

```bash
mkdir -p ~/.codex/skills
cp -R docs/skills/layerling-mcp-skill ~/.codex/skills/
```

Trage danach einen MCP-Server-Eintrag in deine Codex-Konfiguration ein; als Vorlage dient
[`docs/mcp/codex-config.example.toml`](docs/mcp/codex-config.example.toml), wobei du den Skriptpfad durch den absoluten
Pfad auf deinem Rechner ersetzt. Codex neu starten und bitten:

```text
Use $layerling-mcp-skill to list my open layerling editors and inspect the current scene.
```

### Gemini & Antigravity

Für Antigravity liegt eine Kopie des Skills unter `.agents/skills/layerling-mcp-skill` im Repo, die Antigravity von selbst
findet. Für die Gemini CLI kopierst du den Skill aus `docs/skills/layerling-mcp-skill` in deinen globalen Skill-Ordner.

Windows PowerShell:

```powershell
New-Item -ItemType Directory -Force "$env:USERPROFILE\.gemini\skills" | Out-Null
Copy-Item -Recurse -Force "docs\skills\layerling-mcp-skill" "$env:USERPROFILE\.gemini\skills\layerling-mcp-skill"
```

macOS oder Linux:

```bash
mkdir -p ~/.gemini/skills
cp -R docs/skills/layerling-mcp-skill ~/.gemini/skills/
```

Trage danach den Server in die `settings.json` der Gemini CLI oder die `mcp_config.json` von Antigravity ein; als Vorlage
dient [`docs/mcp/gemini-config.example.json`](docs/mcp/gemini-config.example.json), wobei du den Skriptpfad durch den
absoluten Pfad auf deinem Rechner ersetzt. Den Client neu starten und bitten:

```text
Use the layerling MCP tools to list my open layerling editors and inspect the current scene.
```

### Eine KI an eine Kopie auf NAS oder Server lassen

Eine Kopie, die du selbst betreibst (das Docker-Image auf einer NAS, ein Heimserver), kann einen KI-Client ihre offenen
Editoren übers Netz steuern lassen. Das ist **standardmäßig aus**, denn wer die Brücke steuern kann, kann die offenen
Entwürfe lesen und ändern. Mit zwei Einstellungen auf dem Server schaltest du es ein, sie werden beim Start gelesen - das
fertige Image braucht keinen Neubau:

```yaml
environment:
  LAYERLING_MCP_REMOTE: "true"
  LAYERLING_MCP_TOKEN: "ein-langes-zufaelliges-geheimnis-mit-mindestens-16-zeichen"
```

Ohne Schlüssel von mindestens 16 Zeichen bleibt die Brücke zu. Dann:

1. Einen Editor-Tab dieser Kopie im Browser öffnen, z. B. `http://nas:3000/?editor=1`, und offen lassen.
2. Dem MCP-Client Adresse und denselben Schlüssel geben: `LAYERLING_URL=http://nas:3000` und
   `LAYERLING_MCP_TOKEN=<der Schlüssel>` in seiner Konfiguration (Beispiele in `docs/mcp`).

Der Schlüssel schützt die Befehle: Nur ein Client, der ihn mitschickt, kann die Editoren auflisten oder steuern. Die
Editor-Seiten brauchen keinen, zählen aber nur, wenn sie Seiten dieser Kopie sind und unter einer Adresse oder einem Namen
geöffnet wurden, den nur jemand in deinem eigenen Netz benutzen kann (eine IP-Adresse, ein Name ohne Punkt oder einer
auf `.local` oder `.lan`). So kann keine Webseite im Internet über deinen Browser an die NAS gelangen. Öffnest du die
Kopie unter einer echten Domain, etwa hinter einem Reverse-Proxy, trägst du sie in `LAYERLING_MCP_ALLOWED_HOSTS` ein
(durch Kommas getrennt). Nutze das in einem Netz, dem du vertraust, und HTTPS für alles darüber hinaus: Der Schlüssel
wandert in einem Kopfzeilenfeld mit.

## Mitmachen

Beiträge sind willkommen, und du musst kein 3D-Druck-Mensch sein, um zu helfen – ein klarerer Satz in dieser Datei zählt
auch. Gute Anlaufstellen:

- Fehlerbehebungen im Editor
- Testfälle für Geometrie und boolesche Operationen
- Grenzfälle bei Import und Export (STL, OBJ, 3MF, STEP, SVG, DXF)
- Feinschliff an der Oberfläche
- Bildschirmfotos und Videos für die Dokumentation
- Barrierefreiheit und Geschwindigkeit

Lies [.github/CONTRIBUTING.md](.github/CONTRIBUTING.md), bevor du einen Pull Request öffnest. Was sich in welcher Version
geändert hat, steht im [Changelog](docs/CHANGELOG.md).

## Sicherheit

Bitte eröffne für sicherheitsrelevante Meldungen keine öffentlichen Issues. Der Meldeweg steht in
[.github/SECURITY.md](.github/SECURITY.md).

## Woher das kommt

layerling ist ein Fork von [SketchForge-3D](https://github.com/Formsmith746/SketchForge-3D) von Formsmith746 und den
SketchForge-Beitragenden. Der Fork begann am 16. September 2026 auf Basis von SketchForge 1.0.9. SketchForge bleibt ein
hervorragendes Projekt und der Grund, warum es dieses hier gibt.

## Marken

Tinkercad ist eine Marke von Autodesk, Inc. layerling ist ein unabhängiges Projekt und steht in keiner Verbindung zu Autodesk, wird nicht von Autodesk unterstützt oder gesponsert.

## Lizenz

Copyright (C) 2026 layerling contributors.
Copyright (C) 2026 SketchForge contributors.

layerling ist eine abgewandelte Fassung von SketchForge-3D und steht unter der **GNU Affero General Public License v3.0
only** (`AGPL-3.0-only`) – derselben Lizenz wie das Original. Siehe [LICENSE](LICENSE).

Wenn du layerling änderst und die geänderte Fassung über ein Netz zugänglich machst, verpflichtet dich Abschnitt 13 der
Lizenz, den entsprechenden Quelltext anzubieten. Genau dafür trägt das Dashboard einen **Source**-Verweis: Setze beim
Bauen `NEXT_PUBLIC_SOURCE_CODE_URL` auf die öffentliche Adresse des Quelltextes, aus dem dein Build entstanden ist.
