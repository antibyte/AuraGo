import { describe, expect, it } from "vitest";
import { precachePaths, serviceWorkerSource } from "../../scripts/generate-service-worker.mjs";

describe("offline copy of layerling", () => {
  it("stores the program but not server scripts, crawler files or the duplicate kernel", () => {
    const paths = precachePaths([
      "index.html",
      "_next/static/chunks/app/page-abc.js",
      "_next/static/media/occt-wasm.6db3513f.wasm",
      "occt/5.3.5-layerling.1/occt-wasm.wasm",
      "manifold.wasm",
      "store.php",
      "kontakt.php",
      "robots.txt",
      "sitemap.xml",
      "index.txt",
      "404.html",
      "404/index.html",
      "sw.js",
      "_next/static/chunks/main.js.map",
    ]);
    expect(paths).toEqual([
      "/",
      "/_next/static/chunks/app/page-abc.js",
      "/manifold.wasm",
      "/occt/5.3.5-layerling.1/occt-wasm.wasm",
    ]);
  });

  it("writes a service worker that is valid JavaScript and carries its version", () => {
    const source = serviceWorkerSource("abc123", ["/", "/manifold.wasm"]);
    expect(() => new Function(source)).not.toThrow();
    expect(source).toContain('"abc123"');
    expect(source).toContain('["/","/manifold.wasm"]');
  });

  it("keeps the guide's pages for offline use but not its pictures", () => {
    const paths = precachePaths([
      "anleitung/index.html",
      "anleitung/formen.html",
      "anleitung/img/editor-overview.webp",
      "guide/shapes.html",
      "guide/img/editor-overview.webp",
    ]);
    expect(paths).toEqual(["/anleitung/formen.html", "/anleitung/index.html", "/guide/shapes.html"]);
  });

  /*
   * A page left open across an update loads some files only when it needs
   * them, such as the CAD workers. The new version's service worker took over
   * and deleted the old copy, and the server no longer had the files either:
   * "worker failed to start" (discussion #88).
   */
  describe("across an update", () => {
    type Handler = (event: Record<string, unknown>) => void;
    const ORIGIN = "https://layerling.test";

    function browser(server: Set<string>) {
      const stores = new Map<string, Map<string, string>>();
      const network: string[] = [];
      const cacheFor = (name: string) => {
        if (!stores.has(name)) stores.set(name, new Map());
        const store = stores.get(name)!;
        return {
          async addAll(requests: Array<{ url: string }>) {
            for (const request of requests) store.set(request.url, `${name}:${request.url}`);
          },
          async match(path: string) {
            return store.has(path) ? new Response(store.get(path)) : undefined;
          },
          async put(path: string, response: Response) {
            store.set(path, await response.text());
          },
        };
      };
      const caches = {
        open: async (name: string) => cacheFor(name),
        keys: async () => [...stores.keys()],
        delete: async (name: string) => stores.delete(name),
        async match(path: string, options?: { cacheName?: string }) {
          const names = options?.cacheName ? [options.cacheName] : [...stores.keys()];
          for (const name of names) {
            const hit = await stores.get(name)?.has(path) ? new Response(stores.get(name)!.get(path)) : undefined;
            if (hit) return hit;
          }
          return undefined;
        },
      };
      const fetchFromServer = async (request: string | { url: string }) => {
        const url = typeof request === "string" ? request : request.url;
        const path = url.startsWith(ORIGIN) ? url.slice(ORIGIN.length) : url;
        network.push(path);
        return server.has(path) ? new Response(`server:${path}`) : new Response("missing", { status: 404 });
      };
      class FakeRequest {
        url: string;
        constructor(url: string) {
          this.url = url;
        }
      }
      let handlers = new Map<string, Handler>();
      const self = {
        location: { origin: ORIGIN },
        addEventListener: (type: string, handler: Handler) => handlers.set(type, handler),
        skipWaiting: async () => undefined,
        clients: { claim: async () => undefined },
      };
      const lifecycle = async (type: string) => {
        const waits: Promise<unknown>[] = [];
        handlers.get(type)?.({ waitUntil: (promise: Promise<unknown>) => waits.push(promise) });
        await Promise.all(waits);
      };
      return {
        stores,
        network,
        async install(version: string, paths: string[]) {
          handlers = new Map();
          new Function("self", "caches", "fetch", "Request", "Response", serviceWorkerSource(version, paths))(self, caches, fetchFromServer, FakeRequest, Response);
          await lifecycle("install");
          await lifecycle("activate");
        },
        async request(path: string) {
          let answer: Promise<Response> | undefined;
          handlers.get("fetch")?.({
            request: { method: "GET", url: ORIGIN + path, mode: "no-cors" },
            respondWith: (promise: Promise<Response>) => {
              answer = promise;
            },
          });
          const response = await (answer ?? fetchFromServer(path));
          return { status: response.status, body: await response.text() };
        },
      };
    }

    it("still serves an open page of the previous version its worker", async () => {
      const server = new Set(["/", "/_next/static/chunks/233.old.js"]);
      const client = browser(server);
      await client.install("v1", ["/", "/_next/static/chunks/233.old.js"]);
      // The deploy replaces the files on the server, and the new worker takes over.
      server.clear();
      ["/", "/_next/static/chunks/233.new.js"].forEach((path) => server.add(path));
      await client.install("v2", ["/", "/_next/static/chunks/233.new.js"]);

      const old = await client.request("/_next/static/chunks/233.old.js");
      expect(old.status).toBe(200);
      expect(old.body).toBe("layerling-v1:/_next/static/chunks/233.old.js");
      const fresh = await client.request("/_next/static/chunks/233.new.js");
      expect(fresh.body).toBe("layerling-v2:/_next/static/chunks/233.new.js");
    });

    it("keeps the copy an older service worker left without a list", async () => {
      const client = browser(new Set(["/"]));
      client.stores.set("layerling-before", new Map([["/_next/static/chunks/233.before.js", "layerling-before:/_next/static/chunks/233.before.js"]]));
      await client.install("v1", ["/"]);
      expect((await client.request("/_next/static/chunks/233.before.js")).status).toBe(200);
    });

    it("keeps the last three versions and lets older ones go", async () => {
      const client = browser(new Set(["/"]));
      for (const version of ["v1", "v2", "v3", "v4"]) await client.install(version, ["/"]);
      expect([...client.stores.keys()].filter((name) => name !== "layerling-meta").sort()).toEqual(["layerling-v2", "layerling-v3", "layerling-v4"]);
      // Installing the same version again does not push the others out.
      await client.install("v4", ["/"]);
      expect([...client.stores.keys()].filter((name) => name !== "layerling-meta").sort()).toEqual(["layerling-v2", "layerling-v3", "layerling-v4"]);
    });
  });
});
