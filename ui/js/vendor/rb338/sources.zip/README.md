# RB-338 engine: corresponding source

The OpenRB-338 ReBirth RB-338 engine compiled to WebAssembly for AuraGo's Synth Studio. GPL-3.0-only (LICENSE.txt).

- Upstream: https://github.com/pingw33n/OpenRB-338, commit 0bebfcdfd544b3cdea14536f19fb28a8de314df5 (orb-engine, rbs and rbm are used unchanged).
- Wrapper crate: aurago-rb338/ (raw extern "C" ABI, no imports). Pinned toolchain: Rust 1.99.1, target wasm32-unknown-unknown.
- vendor/ holds the exact sources of every dependency (cargo vendor --versioned-dirs). .cargo/config.toml redirects cargo to it, so the build works offline.
- The kit Standard.rbm is not repeated in this archive; it ships next to it as Standard.rbm (SHA-256 6355b5f14fc2ebfe7ed9e6e42208f97817f96c5e30ed42fdca4205d3cdab5fbe, 2572792 bytes). rbm references it through include_bytes!("../../../assets/Standard.rbm"), which from vendor/rbm-0.1.0/src is assets/Standard.rbm at the root of the unpacked archive, so copy it there before building (step 1 below). The shipped wasm itself does not contain it; the host passes the kit to orb_create.
- aurago/ holds the AuraGo JavaScript of the module (model, host, worklet, worker and panel sources) and the build script. Concatenate the rack and sequencer sources in that order to assemble the panel. Names the build script collects when they exist: ui/js/desktop/apps/synth-studio-rb338-model.js, ui/js/desktop/apps/synth-studio-rb338-host.js, ui/js/desktop/apps/synth-studio-rb338-worklet.js, ui/js/desktop/apps/synth-studio-rb338-worker.js, ui/js/desktop/apps/synth-studio-rb338-rack.js, ui/js/desktop/apps/synth-studio-rb338-sequencer.js. This archive was built with: ui/js/desktop/apps/synth-studio-rb338-model.js, ui/js/desktop/apps/synth-studio-rb338-host.js, ui/js/desktop/apps/synth-studio-rb338-worklet.js, ui/js/desktop/apps/synth-studio-rb338-worker.js, ui/js/desktop/apps/synth-studio-rb338-rack.js, ui/js/desktop/apps/synth-studio-rb338-sequencer.js.

## Rebuild the wasm

Unpack this archive into a directory D (absolute path, no need for a particular location), then:

```
1. mkdir D/assets && cp Standard.rbm D/assets/Standard.rbm      (the Standard.rbm shipped next to this archive; check its SHA-256)
2. cd D/aurago-rb338
3. set the path-remap flags (below)
4. cargo +1.99.1 build --release --locked --offline --target wasm32-unknown-unknown
```

The result is target/wasm32-unknown-unknown/release/aurago_rb338.wasm (rb338-engine.wasm in the AuraGo tree). Absolute build paths would otherwise end up in the binary, so the shipped wasm was built with these rustc flags (cargo reads them from CARGO_ENCODED_RUSTFLAGS, separated by the byte 0x1f, which keeps paths with spaces intact; plain RUSTFLAGS works when no path contains a space):

```
--remap-path-prefix=D/aurago-rb338=/aurago-rb338
--remap-path-prefix=D/vendor=/vendor
--remap-path-prefix=$CARGO_HOME=/cargo      (CARGO_HOME defaults to ~/.cargo)
```

With the same toolchain the rebuilt wasm is byte-identical to rb338-engine.wasm. node scripts/build-rb338-vendor.mjs --verify-sources in an AuraGo checkout performs exactly these steps.

## Rebuild every artefact in an AuraGo checkout

```
npm ci
node scripts/build-rb338-vendor.mjs
```

AuraGo: https://github.com/antibyte/AuraGo
