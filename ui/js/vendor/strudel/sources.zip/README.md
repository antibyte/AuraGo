# Strudel 1.3.0 sources

Npm distributions and their complete shipped sources, including transitive dependencies. Versions and licenses are in manifest.json. Reproduce the browser runtime with npm ci in the AuraGo source checkout, then node scripts/build-strudel-vendor.mjs. Upstream repository: https://codeberg.org/uzu/strudel. AuraGo rebundles web.mjs with esbuild; no upstream source is changed. Shared-worker clock synchronization is disabled in the integration.
